from __future__ import print_function
# 多只股票，改不改进记忆性，加不加注意力机制
import csv
import tabnanny

import torchvision
import torchvision.transforms as transforms
import os
import time

from matplotlib import pyplot as plt
from sklearn import preprocessing
from sklearn.metrics import confusion_matrix
from plot_confmat import plot_confusion_matrix
from M_minst_spike_C_c_C import*
# from net_model import SCNN as CONVLSTM
# from net_model_convlstm import *
# os.environ['CUDA_VISIBLE_DEVICES'] = "3"
import cv2
from data import *
from torch.utils.data import DataLoader
import numpy as np
import random
torch.autograd.set_detect_anomaly(True)
# 考虑关系信息
names = 'spiking_model2'
# data_path = './raw/'  # ta" if torch.cuda.is_available() else "cpu")
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
annotation_path  ='M_cls_M_train1/act_bliz_train.txt'
annotation_path1 ='M_cls_M_train1/ea_train.txt'
annotation_path2 ='M_cls_M_train1/nintendo_train.txt'
annotation_path3 ='M_cls_M_train1/take_two_train.txt'
annotation_path4 ='M_cls_M_train1/tencent_train.txt'
# 远程服务器只能识别"/"路径格式
with open(annotation_path,'r') as f:
    lines = f.readlines()
with open(annotation_path1,'r') as f1:
    lines1 = f1.readlines()
with open(annotation_path2, 'r') as f2:
    lines2 = f2.readlines()
with open(annotation_path3, 'r') as f3:
    lines3 = f3.readlines()
with open(annotation_path4, 'r') as f4:
    lines4 = f4.readlines()
np.random.seed(10101)
lines6 = []
lines6 .append(lines)
lines6.append(lines1)
lines6.append(lines2)
lines6.append(lines3)
lines6.append(lines4)

l1 = np.array(lines6)
l2 = l1.transpose()
# np.random.shuffle(l2)
l3 = l2.transpose()
bannotation_path='M_cls_M_test1/act_bliz_test.txt'
bannotation_path1='M_cls_M_test1/ea_test.txt'
bannotation_path2='M_cls_M_test1/nintendo_test.txt'
bannotation_path3='M_cls_M_test1/take_two_test.txt'
bannotation_path4 ='M_cls_M_test1/tencent_test.txt'
# 远程服务器只能识别"/"路径格式
with open(bannotation_path,'r') as f:
    blines=f.readlines()
with open(bannotation_path1,'r') as f1:
    blines1=f1.readlines()
with open(bannotation_path2, 'r') as f2:
    blines2 = f2.readlines()
with open(bannotation_path3, 'r') as f3:
    blines3 = f3.readlines()
with open(bannotation_path4, 'r') as f4:
    blines4 = f4.readlines()
np.random.seed(10101)
blines6 = []
blines6 .append(blines)
blines6.append(blines1)
blines6.append(blines2)
blines6.append(blines3)
blines6.append(blines4)

bl1 = np.array(blines6)
bl2 = bl1.transpose()
# np.random.shuffle(bl2)
bl3 = bl2.transpose()
# np.random.shuffle(lines)#打乱数据，这个地方不能打乱数据
# 这边把数据的变化进行打乱，必须是不同日期的同时进行处理
np.random.seed(None)
num_val=int(len(lines)*0.2)
num_train=len(lines)-num_val
# 以上两个变量并没有在问题中实际用到
#输入图像大小
# 在后面还是要与VGG网络进行对比
input_shape=[19,19]
print(len(l3[0]))
print(len(bl3[0]))
# 只有前面是必须打乱的
# 使用这些图像来与CNN来进行结合看看训练效果
# 现在来看的话，出问题的可能就不一定是数据了应该是SNN的模型有问题，使用CNN可以预测出精确度为57.5%，测试集
# 中间是不是还可以融入一些降噪的东西
# 跟老师说一下可以直接看一下CV部分的课程，打一下基础，并且可以将创新网络，进一步对图像尽心了解
# 剩下的时间就是将多个图像进行融合先做一个简单地融合
# 跟学长交流一下，数据量是不是的值还是太少了
# 打好基础才能够游刃有余
train_data=DataGenerator(l3[0][:1900],input_shape,False)
val_data=DataGenerator(bl3[0][:900],input_shape,False)
test_data=DataGenerator(bl3[0][400:900],input_shape,False)
train_data1=DataGenerator(l3[1][:1900],input_shape,False)
val_data1=DataGenerator(bl3[1][:900],input_shape,False)
test_data1=DataGenerator(bl3[1][400:900],input_shape,False)
train_data2=DataGenerator(l3[2][:1900],input_shape,False)
val_data2=DataGenerator(bl3[2][:900],input_shape,False)
test_data2=DataGenerator(bl3[2][400:900],input_shape,False)
train_data3=DataGenerator(l3[3][:1900],input_shape,False)
val_data3=DataGenerator(bl3[3][:900],input_shape,False)
test_data3=DataGenerator(bl3[3][400:900],input_shape,False)
train_data4=DataGenerator(l3[4][:1900],input_shape,False)
val_data4=DataGenerator(bl3[4][:900],input_shape,False)
test_data4=DataGenerator(bl3[4][400:900],input_shape,False)
# 改代码的时候太容易出错了
val_len=len(val_data)
train_loader=DataLoader(train_data,batch_size=20)
val_loader=DataLoader(val_data,batch_size=20)
test_loader=DataLoader(test_data,batch_size=20)
train_loader1=DataLoader(train_data1,batch_size=20)#这里是默认不会打乱的
val_loader1=DataLoader(val_data1,batch_size=20)
test_loader1=DataLoader(test_data1,batch_size=20)
train_loader2=DataLoader(train_data2,batch_size=20)
val_loader2=DataLoader(val_data2,batch_size=20)
test_loader2=DataLoader(test_data2,batch_size=20)
train_loader3=DataLoader(train_data3,batch_size=20)
val_loader3=DataLoader(val_data3,batch_size=20)
test_loader3=DataLoader(test_data3,batch_size=20)
train_loader4=DataLoader(train_data4,batch_size=20)
val_loader4=DataLoader(val_data4,batch_size=20)
test_loader4=DataLoader(test_data4,batch_size=20)

# 这里的测试集数据不太行，应该是后面几天的用
best_acc = 0  # best test accuracy
start_epoch = 0  # start from epoch 0 or last checkpoint epoch
acc_record = list([])
loss_train_record = list([])
loss_test_record = list([])
import torch
print(torch.__version__)  #注意是双下划线
# 调节数据集的比例
snn = SCNN()
# snn = CONVLSTM()
snn.to(device)
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(snn.parameters(), lr=learning_rate)
max_acc = 0
acc_1 = 0
xx = []
yy = []
# ================================== Train ==============================
for real_epoch in range(num_epochs):
    running_loss = 0
    start_time = time.time()
    for epoch in range(1):
        for i, ((images, labels),(images1,labels1),(imagess2,labelss2),(images3,labels3),(images4,labels4)) in enumerate(zip(train_loader,train_loader1 ,train_loader2,train_loader3,train_loader4)):
    #         # --- create zoom-in and zoom-out version of each image
    #         # print(labels)
            images = images.numpy()
            images1 = images1.numpy()
            imagess2 = imagess2.numpy()
            images3 = images3.numpy()
            images4 = images4.numpy()
            # sclar = preprocessing.MinMaxScaler(feature_range=(0, 1), copy=True)
            # for ii in range(0, 20):
            #     for iii in range(0, 3):
            #         images[ii][iii] = sclar.fit_transform(images[ii][iii])
            #         images1[ii][iii] = sclar.fit_transform(images1[ii][iii])
            #         imagess2[ii][iii] = sclar.fit_transform(imagess2[ii][iii])
            #         images3[ii][iii] = sclar.fit_transform(images3[ii][iii])
            #         images4[ii][iii] = sclar.fit_transform(images4[ii][iii])
            images = torch.from_numpy(images)
            images = images.float().to(device)
            images1 = torch.from_numpy(images1)
            images1 = images1.float().to(device)
            imagess2 = torch.from_numpy(imagess2)
            imagess2 = imagess2.float().to(device)
            images3 = torch.from_numpy(images3)
            images3 = images3.float().to(device)
            images4 = torch.from_numpy(images4)
            images4 = images4.float().to(device)
            # labelss = torch.stack((labels,labels1,labelss2,labels3,labels4),1).float()
            labelss = labelss2
            imagess = torch.cat((images, images1, imagess2, images3, images4), 1)
            images2 = torch.empty((imagess.shape[0] * 2, 50, imagess.shape[2], imagess.shape[3]))
            labels2 = torch.empty((imagess.shape[0] * 2), dtype=torch.int64)
            for j in range(imagess.shape[0]):
                for kk in range(5):
                    img0 = imagess[j, 3*kk, :, :].cpu().numpy()
                    rows, cols = img0.shape
                    for k in range(10):
                        rand1 = random.randint(0, rows//2)
                        rand2 = random.randint(0, cols//2)
                        images2[j * 2, kk+5*k, :, :] = torch.from_numpy(img0)
                        images2[j * 2, kk+5*k, rand1: rand1 + rows//2, rand2: rand2 + cols//2] = 0
                        labels2[j * 2] = labelss[j]
                        # cv2.imshow('image', dst)
                        # cv2.waitKey(100)
                    for k in range(10):
                        rand1 = random.randint(0, rows//2)
                        rand2 = random.randint(0, cols//2)
                        images2[j * 2 + 1, kk+5*k, :, :] = torch.from_numpy(img0)
                        images2[j * 2 + 1, kk+5*k, rand1: rand1 + rows//2, rand2: rand2 + cols//2] = 0
                        labels2[j * 2 + 1] = labelss[j]
            # ----
            snn.zero_grad()
            optimizer.zero_grad()
            images2 = images2.float().to(device)
            # labels2 = labels2.float()
            outputs = snn(images2)
            # print(outputs)
            # print(labels2)
            # labels_ = torch.zeros(batch_size * 2, 5, 2).scatter_(1, labels2.view(-1, 1), 1)
            # print(labels_)
            # 这里应该是不需要进行独热编码的
            loss = criterion(outputs.cpu(), labels2)
            running_loss += loss.item()
            loss.backward()
            optimizer.step()
            if (i+1) % 10 == 0:

                print('Real_Epoch [%d/%d], Epoch [%d/%d], Step [%d/%d], Loss: %.5f'
                        %( real_epoch, num_epochs, epoch, 5, i+1, len(train_data)//batch_size, running_loss))
                running_loss = 0
                print('Time elasped:', time.time() - start_time)
                # break
    xx.append(real_epoch)
    # # ================================== Test ==============================
    correct = 0
    total = 0
    optimizer = lr_scheduler(optimizer, epoch, learning_rate, 40)
    cm = np.zeros((2, 2), dtype=np.int32)

    with torch.no_grad():
        for batch_idx, ((inputs, targets),(inputs1,targets1),(inputs3, targets3),(inputs4,targets4),(inputs5,targets5)) in enumerate(zip(val_loader,val_loader1,val_loader2,val_loader3,val_loader4)):
            inputs = inputs.numpy()
            # 查看tensor数据类型的数据的时候现将数据转换为ndarray
            inputs1 = inputs1.numpy()
            inputs3 = inputs3.numpy()
            inputs4 = inputs4.numpy()
            inputs5 = inputs5.numpy()
            # sclar = preprocessing.MinMaxScaler(feature_range=(0, 1), copy=True)
            # for ii in range(0, 20):
            #     for iii in range(0, 3):
            #         inputs[ii][iii] = sclar.fit_transform(inputs[ii][iii])
            #         inputs1[ii][iii] = sclar.fit_transform(inputs1[ii][iii])
            #         inputs3[ii][iii] = sclar.fit_transform(inputs3[ii][iii])
            #         inputs4[ii][iii] = sclar.fit_transform(inputs4[ii][iii])
            #         inputs5[ii][iii] = sclar.fit_transform(inputs5[ii][iii])
            inputs = torch.from_numpy(inputs)
            inputs = inputs.to(device)
            inputs1 = torch.from_numpy(inputs1)
            inputs1 = inputs1.to(device)
            inputs3 = torch.from_numpy(inputs3)
            inputs3 = inputs3.to(device)
            inputs4 = torch.from_numpy(inputs4)
            inputs4 = inputs4.to(device)
            inputs5 = torch.from_numpy(inputs5)
            inputs5 = inputs5.to(device)
            imagesss = torch.cat((inputs, inputs1, inputs3, inputs4, inputs5), 1)
            # label11 = torch.stack((targets,targets1,targets3,targets4,targets5), 1)
            label11 = targets3
            images22 = torch.empty((imagesss.shape[0] * 2, 50, imagesss.shape[2], imagesss.shape[3]))
            labels22 = torch.empty((imagesss.shape[0] * 2), dtype=torch.int64)
            for j in range(imagesss.shape[0]):
                for kk in range(5):
                    img0 = imagesss[j, 3*kk, :, :].cpu().numpy()
                    rows, cols = img0.shape
                    theta1 = 0
                    theta2 = 360
                    for k in range(10):
                        rand1 = random.randint(0, rows//2)
                        rand2 = random.randint(0, cols//2)
                        images22[j * 2, kk+5*k, :, :] = torch.from_numpy(img0)
                        images22[j * 2, kk+5*k,  rand1: rand1 + rows//2, rand2: rand2 + cols//2] = 0
                        labels22[j * 2] = label11[j]
                        # cv2.imshow('image', dst)
                        # cv2.waitKey(100)
                    for k in range(10):
                        rand1 = random.randint(0, rows//2)
                        rand2 = random.randint(0, cols//2)
                        images22[j * 2 + 1, kk+5*k, :, :] = torch.from_numpy(img0)
                        images22[j * 2 + 1, kk+5*k,  rand1: rand1 + rows//2, rand2: rand2 + cols//2] = 0
                        labels22[j * 2 + 1] = label11[j]
            inputss = images22.to(device)
            optimizer.zero_grad()
            outputs = snn(inputss)
            outputs = outputs.cpu()
            # labels_ = torch.zeros(batch_size * 2, 2).scatter_(1, labels2.view(-1, 1), 1)
            loss = criterion(outputs.cpu(), labels22)
            # 这里要有一个通过以此根据具体的值来对其进行优化
            # prediction = torch.where(outputs>=0.5,1,0)
            # print(loss.item())
            _, predicted = outputs.cpu().max(1)
            # ----- showing confussion matrix -----

            # cm += confusion_matrix(labels2, predicted)
            # ------ showing some of the predictions -----
            # for image, label in zip(inputs, predicted):
            #     for img0 in image.cpu().numpy():
            #         cv2.imshow('image', img0)
            #         cv2.waitKey(100)
            #     print(label.cpu().numpy())

            total += float(labels22.size(0))
            correct += float(predicted.eq(labels22).sum().item())
            if batch_idx % 100 == 0:
                acc = 100. * float(correct) / float(total)
                print(batch_idx, len(val_loader), ' Acc: %.5f' % acc)
    class_names = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9',]
    # plot_confusion_matrix(cm, class_names)
    print('Iters:', epoch, '\n\n\n')
    print('Test Accuracy of the model on the 10000 test images: %.3f' % (100 * correct / total))
    acc = 100. * float(correct) / float(total)
    yy.append(acc)
    acc_record.append(acc)

    if real_epoch == 1:
        acc_1 = acc
    if real_epoch >= 10 and max_acc<acc and acc!=acc_1:
        max_acc = acc
        print(acc)
        print('Saving..')
        state = {
            'net': snn.state_dict(),
            'acc': acc,
            'epoch': epoch,
            'acc_record': acc_record,
        }
        if not os.path.isdir('checkpoint'):
            os.mkdir('checkpoint')
        torch.save(snn.state_dict(), './checkpoint/ckpt' + names + '.t7')
        best_acc = acc
# 创建画布和子图
fig, ax = plt.subplots()

# 绘制折线图
ax.plot(xx, yy)

# 设置 X 轴刻度的位置和标签
# ax.set_xticks([0.4,0.5,0.6,0.7,0.8])
ax.set_yticks([0.45,0.5,0.6,0.7,0.75])
# ax.set_xticklabels([0.4,0.5,0.6,0.7,0.8])
ax.set_title('GAF-SNN')
# 显示图形
plt.show()
# 分别创建不同模型的txt文件，并且将y的值写入到对应的txt文件中

with open('data/GAF-SNN.csv', 'w', newline='') as f:
    # 创建 csv writer 对象
    writer = csv.writer(f)

    # 将列表数据逐行写入到 csv 文件中
    for item in yy:
        writer.writerow([item])
# 想要后面的代码直接解除一次注释就可以
# snn.load_state_dict(torch.load('./checkpoint/ckptspiking_model2.t7'))
# correct = 0
# total = 0
# optimizer = lr_scheduler(optimizer, epoch, learning_rate, 40)
# cm = np.zeros((2, 2), dtype=np.int32)
# with torch.no_grad():
#     for batch_idx, ((inputs, targets),(inputs1,targets1),(inputs3, targets3),(inputs4,targets4),(inputs5,targets5)) in enumerate(zip(val_loader,val_loader1,val_loader2,val_loader3,val_loader4)):
#         inputs = inputs.numpy()
#         # 查看tensor数据类型的数据的时候现将数据转换为ndarray
#         inputs1 = inputs1.numpy()
#         inputs3 = inputs3.numpy()
#         inputs4 = inputs4.numpy()
#         inputs5 = inputs5.numpy()
#         sclar = preprocessing.MinMaxScaler(feature_range=(0, 1), copy=True)
#         for ii in range(0, 20):
#             for iii in range(0, 3):
#                 inputs[ii][iii] = sclar.fit_transform(inputs[ii][iii])
#                 inputs1[ii][iii] = sclar.fit_transform(inputs1[ii][iii])
#                 inputs3[ii][iii] = sclar.fit_transform(inputs3[ii][iii])
#                 inputs4[ii][iii] = sclar.fit_transform(inputs4[ii][iii])
#                 inputs5[ii][iii] = sclar.fit_transform(inputs5[ii][iii])
#         inputs = torch.from_numpy(inputs)
#         inputs = inputs.to(device)
#         inputs1 = torch.from_numpy(inputs1)
#         inputs1 = inputs1.to(device)
#         inputs3 = torch.from_numpy(inputs3)
#         inputs3 = inputs3.to(device)
#         inputs4 = torch.from_numpy(inputs4)
#         inputs4 = inputs4.to(device)
#         inputs5 = torch.from_numpy(inputs5)
#         inputs5 = inputs5.to(device)
#         images = torch.cat((inputs, inputs1, inputs3, inputs4, inputs5), 1)
#         label1 = torch.stack((targets, targets1, targets3, targets4, targets5), 1)
#         images2 = torch.empty((images.shape[0] * 2, 50, images.shape[2], images.shape[3]))
#         labels2 = torch.empty((images.shape[0] * 2, 5), dtype=torch.int64)
#         for j in range(images.shape[0]):
#             for kk in range(5):
#                 img0 = images[j, 3*kk, :, :].cpu().numpy()
#                 rows, cols = img0.shape
#                 theta1 = 0
#                 theta2 = 360
#                 for k in range(10):
#                     rand1 = random.randint(0, rows//2)
#                     rand2 = random.randint(0, cols//2)
#                     images2[j * 2, kk+5*k, :, :] = torch.from_numpy(img0)
#                     images2[j * 2, kk+5*k,  rand1: rand1 + rows//2, rand2: rand2 + cols//2] = 0
#                     labels2[j * 2][kk] = label1[j][kk]
#                     # cv2.imshow('image', dst)
#                     # cv2.waitKey(100)
#                 for k in range(10):
#                     rand1 = random.randint(0, rows//2)
#                     rand2 = random.randint(0, cols//2)
#                     images2[j * 2 + 1, kk+5*k, :, :] = torch.from_numpy(img0)
#                     images2[j * 2 + 1, kk+5*k,  rand1: rand1 + rows//2, rand2: rand2 + cols//2] = 0
#                     labels2[j * 2 + 1][kk] = label1[j][kk]
#         inputs = images2.to(device)
#         optimizer.zero_grad()
#         outputs = snn(inputs)
#         # labels_ = torch.zeros(batch_size * 2, 2).scatter_(1, labels2.view(-1, 1), 1)
#         loss = criterion(outputs.cpu(), labels2)
#         # print(loss.item())
#         # _, predicted = outputs.cpu().max(1)
#
#         # ----- showing confussion matrix -----
#
#         # cm += confusion_matrix(labels2, predicted)
#         # ------ showing some of the predictions -----
#         # for image, label in zip(inputs, predicted):
#         #     for img0 in image.cpu().numpy():
#         #         cv2.imshow('image', img0)
#         #         cv2.waitKey(100)
#         #     print(label.cpu().numpy())
#         prediction = torch.where(outputs >= 0.5, 1, 0)
#         total += float(labels2.size(0)*labels2.size(1))
#         correct += float(prediction.eq(labels2).sum().item())
#         if batch_idx % 100 == 0:
#             acc = 100. * float(correct) / float(total)
#             print(batch_idx, len(val_loader), ' Acc: %.5f' % acc)
# class_names = ['0', '1', '2', '3', '4',
#          '5', '6', '7', '8', '9',]
# plot_confusion_matrix(cm, class_names)
# print('Iters:', epoch, '\n\n\n')
# print('Test Accuracy of the model on the 10000 test images: %.3f' % (100 * correct / total))


