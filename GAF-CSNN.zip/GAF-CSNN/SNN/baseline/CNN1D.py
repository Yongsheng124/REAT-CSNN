import csv

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from matplotlib import pyplot as plt

seq_length = 19


# 分割数据
train_size = 1920
train_size1 = 1990+400+500
train_size2 = 1900+400+500
batch_size = 20
data_test_1 = []
label_test_1 = []
data_head = ['sort_act_bliz_test.npy','sort_ea_test.npy','sort_nintendo_test.npy','sort_take_two_test.npy','sort_tencent_test.npy']
for i in data_head:
    array_1 = np.load("test_series/"+i,allow_pickle=True)
    data_1 = []
    label_1 = []
    for j in range(array_1.shape[0]):
        data_1.append(array_1[j][1])
        label_1.append(array_1[j][2])
    data_test_1.append(data_1)
    label_test_1.append(label_1)
test_data = np.transpose(np.array(data_test_1),(1,0,2))[:900]
test_label = np.transpose(np.array(label_test_1))[:900]
count_2 = np.sum(test_label == 1)
count_1 = np.sum(test_label == 0)
data_train_1 = []
label_train_1 = []
data1_head = ['sort_act_bliz_train.npy','sort_ea_train.npy','sort_nintendo_train.npy','sort_take_two_train.npy','sort_tencent_train.npy']
for i in data1_head:
    array_2 = np.load("train_series/"+i,allow_pickle=True)
    data_2 = []
    label_2 = []
    for j in range(array_2.shape[0]):
        data_2.append(array_2[j][1])
        label_2.append(array_2[j][2])
    data_train_1.append(data_2)
    label_train_1.append(label_2)
train_data = np.transpose(np.array(data_train_1),(1,0,2))[0:1900]
train_label = np.transpose(np.array(label_train_1))[:1900]
count_4 = np.sum(train_label == 1)
count_3 = np.sum(train_label == 0)
# test_data = train_data[:900]
# test_label = train_label[:900]

# X_train, y_train = X[:train_size], y[:train_size]
#
# X_val,y_val = X[1990:train_size1], y[1990:train_size1]
# X_test, y_test = X[train_size1:train_size2], y[train_size1:train_size2]

# 转换数据类型
X_train = torch.from_numpy(train_data).float()
train_x_list = torch.split(X_train,batch_size,dim=0)
y_train = torch.from_numpy(train_label).long()
train_y_list = torch.split(y_train,batch_size,dim=0)
X_val = torch.from_numpy(test_data).float()
val_x_list = torch.split(X_val,batch_size,dim=0)
y_val = torch.from_numpy(test_label).long()
val_y_list = torch.split(y_val,batch_size,dim=0)
# X_test = torch.from_numpy(X_test).float()
# y_test = torch.from_numpy(y_test).long()
class CNN(nn.Module):
    def __init__(self, input_size, output_size):
        super(CNN, self).__init__()
        self.conv1 = nn.Conv1d(input_size, 16, kernel_size=3, stride=1, padding=1)
        self.relu = nn.ReLU()
        self.maxpool = nn.MaxPool1d(kernel_size=2, stride=2)
        self.fc = nn.Linear(64, output_size)

    def forward(self, x):
        out = self.conv1(x)
        out = self.relu(out)
        out = self.maxpool(out)
        out = out.view(out.size(0), -1)
        out = self.fc(out)
        return out

# 准备训练数据和标签
input_size = 5
output_size = 5
# seq_length = 19
# train_data = torch.randn(1000, input_size, seq_length)
# train_labels = torch.randint(0, output_size, (1000,))

# 创建CNN模型实例
model = CNN(input_size, output_size)

# 定义损失函数和优化器
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.0001)

# 进行模型训练
num_epochs = 1
# batch_size = 20
# num_batches = len(train_data) // batch_size
xx = []
yy = []
for i in range(1000):
    for epoch in range(num_epochs):
        running_loss = 0.0
        for train_x,train_y in zip(train_x_list,train_y_list):
            # 获取当前批次的数据和标签
            # batch_data = train_data[batch * batch_size: (batch + 1) * batch_size]
            # batch_labels = train_labels[batch * batch_size: (batch + 1) * batch_size]

            # 梯度清零
            optimizer.zero_grad()

            # 前向传播
            outputs = model(train_x)
            loss = criterion(outputs, train_y.float())

            # 反向传播和优化
            loss.backward()
            optimizer.step()

            running_loss += loss.item()

        if (epoch+1) % 10 == 0:
            print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {running_loss}')
    xx.append(i)
    # 准备测试数据
    # test_data = torch.randn(100, input_size, seq_length)

    # 进行模型预测
    with torch.no_grad():
        total = 0
        correct = 0
        for val_x, val_y in zip(val_x_list, val_y_list):
            y_pred = model(val_x)
            test_loss = criterion(y_pred, val_y)
            # _, predicted = torch.max(y_pred.data, 1)
            predicted = torch.where(y_pred >= 0.5, 1, 0)
            total += predicted.size(0)*5
            correct += (predicted == val_y).sum().item()
        val_accuracy = correct / total
        # test_rmse = scaler.inverse_transform(np.sqrt(test_loss.item()))
        print(f'Test Accuracy: {val_accuracy:.4f},epoch {i}')
        yy.append(val_accuracy)
# 创建画布和子图
fig, ax = plt.subplots()

# 绘制折线图
ax.plot(xx, yy)

# 设置 X 轴刻度的位置和标签
# ax.set_xticks([0.4,0.5,0.6,0.7,0.8])
ax.set_yticks([0.45,0.5,0.6,0.7,0.75])
# ax.set_xticklabels([0.4,0.5,0.6,0.7,0.8])
ax.set_title('CNN1D')
# 显示图形
plt.show()
# 分别创建不同模型的txt文件，并且将y的值写入到对应的txt文件中

with open('data/CNN1D.csv', 'w', newline='') as f:
    # 创建 csv writer 对象
    writer = csv.writer(f)

    # 将列表数据逐行写入到 csv 文件中
    for item in yy:
        writer.writerow([item])