import csv

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import matplotlib.pyplot as plt
# 定义图卷积层
class GCNLayer(nn.Module):
    def __init__(self, in_features, out_features):
        super(GCNLayer, self).__init__()
        self.linear = nn.Linear(in_features, out_features)
        self.activation = nn.ReLU()

    def forward(self, A, X):
        X = torch.matmul(A, X)
        X = self.linear(X)
        X = self.activation(X)
        return X

# 定义多元时间序列预测模型
class GCN_TimeSeries(nn.Module):
    def __init__(self, input_dim, gcn_hidden_dim, rnn_hidden_dim, output_dim, num_layers, dropout_rate):
        super(GCN_TimeSeries, self).__init__()
        self.input_dim = input_dim
        self.gcn_hidden_dim = gcn_hidden_dim
        self.rnn_hidden_dim = rnn_hidden_dim
        self.output_dim = output_dim
        self.num_layers = num_layers
        self.dropout_rate = dropout_rate

        # 定义 GCN 神经网络层结构
        self.gcn1 = GCNLayer(input_dim, gcn_hidden_dim)
        self.gcn2 = GCNLayer(gcn_hidden_dim, gcn_hidden_dim)

        # 定义 RNN 神经网络层结构
        self.rnn = nn.LSTM(gcn_hidden_dim, rnn_hidden_dim, num_layers=num_layers, batch_first=True, dropout=dropout_rate)

        # 定义全连接层
        self.fc = nn.Linear(160, output_dim)

    def forward(self, A, X):
        # GCN 网络层的前向传播
        X = self.gcn1(A.unsqueeze(1), X)
        X = self.gcn2(A.unsqueeze(1), X)
        X = X.squeeze(1)
        # RNN 网络层的前向传播
        # print(1)
        X = X.transpose(1, 2) # 将数据维度转换为(batch_size, seq_len, num_nodes, gcn_hidden_dim)
        batch_size, seq_len, num_nodes, features = X.shape
        hidden_state = torch.zeros(self.num_layers, batch_size, self.rnn_hidden_dim).to(X.device)
        cell_state = torch.zeros(self.num_layers, batch_size, self.rnn_hidden_dim).to(X.device)
        for i in range(seq_len):
            # print(1)
            rnn_out, (hidden_state, cell_state) = self.rnn(X[:, i, :, :], (hidden_state, cell_state))
            if i == 0:
                out = rnn_out[:, -1, :]
            else:
                out = torch.cat((out, rnn_out[:, -1, :]), dim=1)

        # 全连接层的前向传播
        out = F.dropout(out, self.dropout_rate)
        out = self.fc(out)

        return out


# 定义输入变量
batch_size = 20

num_nodes = 5
value = 1.0
size = (batch_size,num_nodes,num_nodes)
data_test_1 = []
label_test_1 = []
data_head = ['sort_act_bliz_test.npy','sort_ea_test.npy','sort_nintendo_test.npy','sort_take_two_test.npy','sort_tencent_test.npy']
for i in data_head:
    array_1 = np.load("test_series/"+i,allow_pickle=True)
    # print(array_1)
    data_1 = []
    label_1 = []
    for j in range(array_1.shape[0]):
        data_1.append(array_1[j][1])
        label_1.append(array_1[j][2])
    data_test_1.append(data_1)
    label_test_1.append(label_1)
test_data = np.transpose(np.array(data_test_1),(1,2,0))[:900]
# np.random.shuffle(test_data)
test_label = np.transpose(np.array(label_test_1))[:900]
# np.random.shuffle(test_label)
count_2 = np.sum(test_label == 1)
count_1 = np.sum(test_label == 0)
data_train_1 = []
label_train_1 = []
data1_head = ['sort_act_bliz_train.npy','sort_ea_train.npy','sort_nintendo_train.npy','sort_take_two_train.npy','sort_tencent_train.npy']
for i in data1_head:
    array_2 = np.load("train_series/"+i,allow_pickle=True)
    data_2 = []
    label_2 = []
    for j in range(array_2.shape[0]):
        data_2.append(array_2[j][1])
        label_2.append(array_2[j][2])
    data_train_1.append(data_2)
    label_train_1.append(label_2)
train_data = np.transpose(np.array(data_train_1),(1,2,0))[0:1900]
train_label = np.transpose(np.array(label_train_1))[:1900]
# np.random.shuffle(train_data)
# np.random.shuffle(train_label)
count_4 = np.sum(train_label == 1)
count_3 = np.sum(train_label == 0)



# 转换数据类型
X_train = torch.from_numpy(train_data).float()
train_x_list = torch.split(X_train,batch_size,dim=0)
y_train = torch.from_numpy(train_label).long()
train_y_list = torch.split(y_train,batch_size,dim=0)
X_val = torch.from_numpy(test_data).float()
val_x_list = torch.split(X_val,batch_size,dim=0)
y_val = torch.from_numpy(test_label).long()
val_y_list = torch.split(y_val,batch_size,dim=0)
input_dim = 1
gcn_hidden_dim = 16
rnn_hidden_dim = 32
output_dim = 5
num_layers = 2
dropout_rate = 0.5
learning_rate = 0.0001
# 创建模型实例
model = GCN_TimeSeries(input_dim, gcn_hidden_dim, rnn_hidden_dim, output_dim, num_layers, dropout_rate)

# 定义损失函数和优化器
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
max_acc = 0

# X = torch.randn(batch_size, seq_len, num_nodes, input_dim)
# 定义超参数
xx = []
yy = []
num_epochs = 1
# 训练模型
for i in range(150):
    for epoch in range(num_epochs):
        loss_sum = 0
        for train_x,train_y in zip(train_x_list,train_y_list):
            model.train()
            A = value * torch.ones(size, dtype=torch.float32)
            optimizer.zero_grad()
            outputs = model(A,train_x.unsqueeze(dim=-1))
            loss = criterion(outputs.float(), train_y.float())
            loss.backward()
            # print(1)
            optimizer.step()
            loss_sum += loss.item()
        if (epoch+1) % 1 == 0:
            print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {loss_sum:.4f}')
    xx.append(i)
    # 测试模型
    model.eval()
    with torch.no_grad():
        total = 0
        correct = 0
        for val_x,val_y in zip(val_x_list,val_y_list):
            A = value * torch.ones(size, dtype=torch.float32)
            y_pred = model(A,val_x.unsqueeze(dim=-1))
            test_loss = criterion(y_pred,val_y)
            # _, predicted = torch.max(y_pred.data, 1)
            predicted = torch.where(y_pred >= 0.5, 1, 0)
            total += predicted.size(0)*5
            correct += (predicted == val_y).sum().item()
        val_accuracy = correct / total
        # test_rmse = scaler.inverse_transform(np.sqrt(test_loss.item()))
        print(f'Test Accuracy: {val_accuracy:.4f},epoch {i}')
        yy.append(val_accuracy)
# 创建画布和子图
fig, ax = plt.subplots()

# 绘制折线图
ax.plot(xx, yy)

# 设置 X 轴刻度的位置和标签
# ax.set_xticks([0.4,0.5,0.6,0.7,0.8])
ax.set_yticks([0.45,0.5,0.6,0.7,0.75])
# ax.set_xticklabels([0.4,0.5,0.6,0.7,0.8])
ax.set_title('GCN')
plt.show()

with open('data/GCN.csv', 'w', newline='') as f:

    writer = csv.writer(f)

    for item in yy:
        writer.writerow([item])