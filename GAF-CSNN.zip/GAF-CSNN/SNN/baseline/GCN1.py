import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.model_selection import train_test_split
import numpy as np

# 定义GCN模型
class GCN(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(GCN, self).__init__()
        self.linear1 = nn.Linear(input_dim, hidden_dim)
        self.relu = nn.ReLU()
        self.linear2 = nn.Linear(hidden_dim, output_dim)
        self.softmax = nn.Softmax(dim=1)

    def forward(self, adj, x):
        x = self.linear1(torch.matmul(adj, x))
        x = self.relu(x)
        x = self.linear2(torch.matmul(adj, x))
        x = self.softmax(x)
        return x

# 准备数据
adjacency_matrix = np.array([[1.0, 1.0, 1.0,1.0,1.0],
                             [1.0, 1.0, 1.0, 1.0, 1.0],
                             [1.0, 1.0, 1.0, 1.0, 1.0],
                             [1.0, 1.0, 1.0, 1.0, 1.0],
                             [1.0, 1.0, 1.0, 1.0, 1.0],])

# features = np.array([[1.0, 2.0, 3.0],
#                      [4.0, 5.0, 6.0],
#                      [7.0, 8.0, 9.0]])
data_test_1 = []
label_test_1 = []
data_head = ['sort_act_bliz_test.npy','sort_ea_test.npy','sort_nintendo_test.npy','sort_take_two_test.npy','sort_tencent_test.npy']
for i in data_head:
    array_1 = np.load("test_series/"+i,allow_pickle=True)
    data_1 = []
    label_1 = []
    for j in range(array_1.shape[0]):
        data_1.append(array_1[j][1])
        label_1.append(array_1[j][2])
    data_test_1.append(data_1)
    label_test_1.append(label_1)
test_data = np.transpose(np.array(data_test_1),(1,2,0))[:900]
test_label = np.transpose(np.array(label_test_1))[:900]
features_test = test_data
labels_test = test_label
count_2 = np.sum(test_label == 1)
count_1 = np.sum(test_label == 0)
data_train_1 = []
label_train_1 = []
data1_head = ['sort_act_bliz_train.npy','sort_ea_train.npy','sort_nintendo_train.npy','sort_take_two_train.npy','sort_tencent_train.npy']
for i in data1_head:
    array_2 = np.load("train_series/"+i,allow_pickle=True)
    data_2 = []
    label_2 = []
    for j in range(array_2.shape[0]):
        data_2.append(array_2[j][1])
        label_2.append(array_2[j][2])
    data_train_1.append(data_2)
    label_train_1.append(label_2)
train_data = np.transpose(np.array(data_train_1),(1,2,0))[0:1900]
train_label = np.transpose(np.array(label_train_1))[:1900]
features_train = train_data
labels_train  = train_label
# labels = np.array([[0.2, 0.8],
#                    [0.4, 0.6],
#                    [0.3, 0.7]])

# 划分训练集和测试集
# adj_train, adj_test, features_train, features_test, labels_train, labels_test = train_test_split(
#     adjacency_matrix, features, labels, test_size=0.2, random_state=42)

# 转换为PyTorch的Tensor
adj_train = torch.from_numpy(adjacency_matrix).float()
adj_test = torch.from_numpy(adjacency_matrix).float()
features_train = torch.from_numpy(features_train).float()
features_test = torch.from_numpy(features_test).float()
labels_train = torch.from_numpy(labels_train).float()
labels_test = torch.from_numpy(labels_test).float()

# 创建GCN模型实例
input_dim = features_train.size(1)
hidden_dim = 64
output_dim = labels_train.size(1)
model = GCN(input_dim, hidden_dim, output_dim)

# 定义损失函数和优化器
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.0001)

# 模型训练
num_epochs = 100
for epoch in range(num_epochs):
    # 前向传播

    output = model(adj_train, features_train)
    loss = criterion(output, labels_train)

    # 反向传播和优化
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    # 打印损失值
    if (epoch+1) % 10 == 0:
        print('Epoch [{}/{}], Loss: {:.4f}'.format(epoch+1, num_epochs, loss.item()))

# 模型测试
with torch.no_grad():
    model.eval()
    test_output = model(adj_test, features_test)
    test_loss = criterion(test_output, labels_test)

    # 计算预测结果的精度
    predicted_labels = torch.argmax(test_output, dim=1)
    true_labels = torch.argmax(labels_test, dim=1)
    accuracy = (predicted_labels == true_labels).sum().item() / len(labels_test)

    print('Test Loss: {:.4f}, Accuracy: {:.2f}%'.format(test_loss.item(), accuracy * 100))


