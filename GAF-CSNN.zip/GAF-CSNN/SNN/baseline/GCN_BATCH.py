from util import *
from Merics import RMSE, Acc, F1
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
import math
import random
import pandas as pd
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
from torch import nn, optim
import numpy as np
import os
import time
import scipy.sparse as sp
import torch.nn.functional as F
from torch.nn.parameter import Parameter
from torch.nn.modules.module import Module
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'

class GraphConvolution(Module):

    def __init__(self, in_features, out_features, bias=True):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)

    def forward(self, input, adj):
        support = torch.mm(input, self.weight)
        output = torch.spmm(adj, support)
        if self.bias is not None:
            return output + self.bias
        else:
            return output

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + ' -> ' \
               + str(self.out_features) + ')'

class GCN(nn.Module):
    def __init__(self, nfeat, nhid, dropout):
        super(GCN, self).__init__()

        self.gc1 = GraphConvolution(nfeat, 16)
        self.gc2 = GraphConvolution(16, 16)

        self.dropout = dropout
        self.fc=nn.Linear(16,2)
        self.sm=nn.Softmax(dim=1)

    def forward(self, x, adj):
        x = F.relu(self.gc1(x, adj))
        x=F.relu(self.gc2(x,adj))
        x=self.fc(x)
        x=self.sm(x)
        return x
def train(train_data,train_label,A):
    print('---------------正在训练---------------')
    epochs=100
    model=GCN(nfeat=1,nhid=32,dropout=.5)  #论文中参数 3层
    lossfun=nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.005,weight_decay=5e-4)
    #device='cuda' if torch.cuda.is_available() else 'cpu'
    device='cuda'
    train_data=train_data.float()
    train_label=train_label.float()
    A=A.float()

    train_data=train_data.to(device)
    train_label=train_label.to(device)
    A=A.to(device)
    model=model.to(device)
    lossfun=lossfun.to(device)

    for epoch in range(epochs):
        print('第',epoch+1,'/',epochs,'轮')
        start=time.time()
        days = list(range(1920))[20:]
        random.shuffle(days)
        avg_loss=0
        for day in days:
            model.train()
            optimizer.zero_grad()

            data=train_data[:,day-1,:]
            label=train_label[:,day].long()

            out=model(data,A)
            # print(out)
            out=out.squeeze()
            loss = lossfun(out, label)
            avg_loss+=loss

            loss.backward()
            optimizer.step()

        avg_loss = avg_loss /len(days)
        end=time.time()
        print('loss={:.8f}'.format(avg_loss.item()),'共耗时:',end-start,'秒')
    #torch.save(model,'GCN_model.pth')
    return model

def test(model,test_data,test_label,A):
    #device = 'cuda' if torch.cuda.is_available() else 'cpu'
    device='cuda'
    test_data=test_data.float()
    test_label=test_label.float()
    A=A.float()

    A=A.to(device)
    test_data=test_data.to(device)
    test_label=test_label.to(device)
    model=model.to(device)
    days=900

    pred=[]
    true=[]

    for day in range(20,20+days):
        model.eval()
        data=test_data[:,day-1]
        label=test_label[:,day].squeeze()

        out = model(data, A)

        label=label.squeeze()
        out=out.squeeze()
        # print(out)
        out=torch.argmax(out,dim=1)

        for i in range(5):
            pred.append(out[i].item())
            true.append(label[i].item())



    print(len(pred))
    print(sum(pred))
    print(len(pred)-sum(pred))
    pre=torch.tensor(pred,dtype=torch.float)
    true=torch.tensor(true,dtype=torch.float)

    print(pre[:20])
    print(true[:20])
    # 真实的标签也是这里给出涨跌的标签
    acc=Acc(torch.where(pre>=0.5,1,0),torch.where(true>=0.5,1,0))
    f1=F1(torch.where(pre>=0.5,1,0),torch.where(true>=0.5,1,0))
    #rmse=RMSE(pre,true)
    #f1=F1(torch.where(pre>=0,1,0),torch.where(true>=0,1,0))
    print('GCN:''ACC是{:.2f}'.format(acc * 100), '%')
    print('GCN:''F1是{:.2f}'.format(f1))


if __name__=='__main__':
    data_path= 'data.npy'
    train_data,train_label,test_data,test_label=load_daily(data_path)
    # 全连接的部分应该是全部都是有相互关系的
    relation_path='relation.pt'
    A=load_THS_adj2(relation_path)

    # relation_path='Adj1_potentials.torch'
    # A=load_THS_adj3(relation_path)

    train_label = torch.where(train_label >= 0, 1, 0)
    test_label = torch.where(test_label >= 0, 1, 0)
    model=train(train_data,train_label,A)

    #model=torch.load('GCN_model.pth')

    test(model,test_data,test_label,A)
