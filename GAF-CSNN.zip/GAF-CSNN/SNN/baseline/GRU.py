import csv

import torch
import torch.nn as nn
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from sklearn.preprocessing import MinMaxScaler

# 加载数据
# df = pd.read_csv('act_bliz.csv')
#
# # 数据预处理
# scaler = MinMaxScaler()
# data = scaler.fit_transform(df[['Close']].values)
data = np.load('data1.npy')
# 将数据转换为时序数据
def create_sequences(data, seq_length):
    xs = []
    ys = []
    for i in range(len(data)-seq_length-1):
        x = data[i:(i+seq_length)]
        y = [1 if data[i+seq_length][j] > data[i+seq_length-1][j] else 0 for j in range(5)]
        xs.append(x)
        ys.append(y)
    return np.array(xs), np.array(ys)

seq_length = 20
X, y = create_sequences(data, seq_length)

# 分割数据
print(len(X))
train_size = 1900
train_size1 = 1900+400+500
train_size2 = 1900+400+500
data_test_1 = []
label_test_1 = []
data_head = ['sort_act_bliz_test.npy','sort_ea_test.npy','sort_nintendo_test.npy','sort_take_two_test.npy','sort_tencent_test.npy']
for i in data_head:
    array_1 = np.load("test_series/"+i,allow_pickle=True)
    data_1 = []
    label_1 = []
    for j in range(array_1.shape[0]):
        data_1.append(array_1[j][1])
        label_1.append(array_1[j][2])
    data_test_1.append(data_1)
    label_test_1.append(label_1)
test_data = np.transpose(np.array(data_test_1),(1,2,0))[:900]
test_label = np.transpose(np.array(label_test_1))[:900]
count_2 = np.sum(test_label == 1)
count_1 = np.sum(test_label == 0)
data_train_1 = []
label_train_1 = []
data1_head = ['sort_act_bliz_train.npy','sort_ea_train.npy','sort_nintendo_train.npy','sort_take_two_train.npy','sort_tencent_train.npy']
for i in data1_head:
    array_2 = np.load("train_series/"+i,allow_pickle=True)
    data_2 = []
    label_2 = []
    for j in range(array_2.shape[0]):
        data_2.append(array_2[j][1])
        label_2.append(array_2[j][2])
    data_train_1.append(data_2)
    label_train_1.append(label_2)
train_data = np.transpose(np.array(data_train_1),(1,2,0))[0:1900]
train_label = np.transpose(np.array(label_train_1))[:1900]
count_4 = np.sum(train_label == 1)
count_3 = np.sum(train_label == 0)
# test_data = train_data[:900]
# test_label = train_label[:900]

# X_train, y_train = X[:train_size], y[:train_size]
#
# X_val,y_val = X[1990:train_size1], y[1990:train_size1]
X_test, y_test = X[train_size1:train_size2], y[train_size1:train_size2]
batch_size = 20
# 转换数据类型
X_train = torch.from_numpy(train_data).float()
train_x_list = torch.split(X_train,batch_size,dim=0)
y_train = torch.from_numpy(train_label).float()
train_y_list = torch.split(y_train,batch_size,dim=0)
X_val = torch.from_numpy(test_data).float()
val_x_list = torch.split(X_val,batch_size,dim=0)
y_val = torch.from_numpy(test_label).float()
val_y_list = torch.split(y_val,batch_size,dim=0)
X_test = torch.from_numpy(X_test).float()
y_test = torch.from_numpy(y_test).long()
names = 'gru'

# 定义 GRU 模型
class GRU(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(GRU, self).__init__()
        self.hidden_size = hidden_size
        self.gru = nn.GRU(input_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        h0 = torch.zeros(1, x.size(0), self.hidden_size)
        out, _ = self.gru(x, h0)
        out = self.fc(out[:, -1, :])
        return out
# 定义超参数
input_size = 5
hidden_size = 32
output_size = 5
num_epochs = 1
learning_rate = 0.0001

# 初始化模型
gru_model = GRU(input_size, hidden_size, output_size)

# 定义损失函数和优化器
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(gru_model.parameters(), lr=learning_rate)
max_acc = 0
# 训练模型
xx = []
yy = []
for i in range(150):
    for epoch in range(num_epochs):
        loss_sum = 0
        for train_x, train_y in zip(train_x_list, train_y_list):
            gru_model.train()
            optimizer.zero_grad()
            outputs = gru_model(train_x)
            loss = criterion(outputs.float(), train_y.float())
            loss.backward()
            optimizer.step()
            loss_sum += loss.item()
        if (epoch + 1) % 10 == 0:
            print(f'Epoch [{epoch + 1}/{num_epochs}], Loss: {loss_sum:.4f}')
    xx.append(i)
    # 测试模型
    gru_model.eval()
    with torch.no_grad():
        y_pred = gru_model(X_val)
        test_loss = criterion(y_pred, y_val)
        # _, predicted = torch.max(y_pred.data, 1)
        # total = predicted.size(0)
        # correct = (predicted == y_val).sum().item()
        predicted = torch.where(y_pred >= 0.5, 1, 0)
        total = predicted.size(0)*5
        correct = (predicted == y_val).sum().item()
        val_accuracy = correct / total
        # test_loss = scaler.inverse_transform(np.sqrt(test_loss.item()))
        print(f' Test Accuracy: {val_accuracy:.4f} epoch: {i}')
        yy.append(val_accuracy)
# 创建画布和子图
fig, ax = plt.subplots()

# 绘制折线图
ax.plot(xx, yy)

# 设置 X 轴刻度的位置和标签
# ax.set_xticks([0.4,0.5,0.6,0.7,0.8])
ax.set_yticks([0.45,0.5,0.6,0.7,0.75])
# ax.set_xticklabels([0.4,0.5,0.6,0.7,0.8])
ax.set_title('GRU')
# 显示图形
plt.show()
# 分别创建不同模型的txt文件，并且将y的值写入到对应的txt文件中

with open('data/GRU.csv', 'w', newline='') as f:
    # 创建 csv writer 对象
    writer = csv.writer(f)

    # 将列表数据逐行写入到 csv 文件中
    for item in yy:
        writer.writerow([item])
#         if max_acc<val_accuracy and i>10:
#             max_acc = val_accuracy
#             torch.save(gru_model.state_dict(), './checkpoint/ckpt' + names + '.t7')
# gru_model.load_state_dict(torch.load('./checkpoint/ckptgru.t7'))
# correct_l = 0
# total_l = 0
# with torch.no_grad():
#     for ii in range(10):
#         y_pred = gru_model(X_test)
#         test_loss = criterion(y_pred, y_test)
#         _, predicted = torch.max(y_pred.data, 1)
#         total = predicted.size(0)
#         correct = (predicted == y_test).sum().item()
#         correct_l += correct
#         total_l += total
#     test_accuracy = correct / total
#
#         # test_loss = scaler.inverse_transform(np.sqrt(test_loss.item()))
#     print(f' Test Accuracy: {test_accuracy:.4f}')