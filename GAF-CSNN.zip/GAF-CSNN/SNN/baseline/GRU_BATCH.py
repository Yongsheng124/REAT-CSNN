import math
import random
import pandas as pd
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
from torch import nn, optim
import numpy as np
import os
import time
import scipy.sparse as sp
import torch.nn.functional as F
from torch.nn.parameter import Parameter
from torch.nn.modules.module import Module
from util import *
from Merics import *

os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'

class GRU_gate(nn.Module):
    def __init__(self,input_size,output_size,activation,companies=5):
        super(GRU_gate, self).__init__()
        self.activation = activation
        self.W = Parameter(torch.FloatTensor(input_size, output_size))
        self.reset_param(self.W)

        self.bias = Parameter(torch.zeros(companies,output_size))


    def reset_param(self, t):
        # Initialize based on the number of columns
        stdv = 1. / math.sqrt(t.size(1))
        t.data.uniform_(-stdv, stdv)

    def forward(self,x):
        return self.activation(x.matmul(self.W)+self.bias)

class GRUcell(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(GRUcell, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.update=GRU_gate(input_size+hidden_size,hidden_size,nn.Sigmoid())
        self.reset=GRU_gate(input_size+hidden_size,hidden_size,nn.Sigmoid())
        self.hat=GRU_gate(input_size+hidden_size,hidden_size,nn.Tanh())

    def forward(self,xt,hidden):
        zt=self.update(torch.cat((hidden,xt),dim=1))
        rt=self.reset(torch.cat((hidden,xt),dim=1))
        h_t=self.hat(torch.cat((hidden*rt,xt),dim=1))
        ht=(1-zt)*hidden+zt*h_t
        return ht

class GRU(nn.Module):
    def __init__(self,input_size,hidden_size,steps,companies=5):
        super(GRU, self).__init__()
        self.companies = companies
        self.steps = steps

        self.hidden_dim = hidden_size
        self.gru_cell = GRUcell(input_size, hidden_size)


    def forward(self,x):
        h = torch.FloatTensor(self.companies, self.steps, self.hidden_dim)
        i=0
        hidden=torch.zeros((self.companies,self.hidden_dim))

        for seq in range(self.steps):
            hidden=self.gru_cell(x[:,seq,:],hidden)
            h[:,i,:]=hidden
            i+=1
        return h,hidden

class GRU_BATCH(nn.Module):
    def __init__(self,):
        super(GRU_BATCH, self).__init__()
        #self.gru1=nn.GRU(5,64,num_layers=1,batch_first=True)
        #self.gru2=nn.GRU(64,64,num_layers=1,batch_first=True)
        self.gru1=GRU(1,128,20)
        self.fc=nn.Linear(128,2)
        self.sm=nn.Softmax(dim=1)

    def forward(self, x):#(600,5,5)
        h,hidden=self.gru1(x)
        #h=F.dropout(h,.5,training=True)
        #h,hidden=self.gru2(h)
        #hidden=hidden.squeeze()
        #hidden=hidden[-1]
        x=self.fc(hidden)
        x=self.sm(x)
        return x


#训练1个的
def train(train_data,train_label):
    print('---------------正在训练---------------')

    epochs=50
    model=GRU_BATCH()  #2层128


    lossfun=nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(),lr=0.001,weight_decay=5e-4)

    device='cpu'
    train_data=train_data.float()
    train_label=train_label.float()

    train_data=train_data.to(device)
    train_label=train_label.to(device)

    model=model.to(device)
    lossfun=lossfun.to(device)

    for epoch in range(epochs): #训练 从第十天预测到第600天
        print('第',epoch+1,'/',epochs,'轮')
        start=time.time()
        days = list(range(1920))[20:]
        random.shuffle(days)
        avg_loss=0

        for day in days:
            model.train()
            optimizer.zero_grad()

            data=train_data[:,day-20:day,:]
            label=train_label[:,day].squeeze().long()

            out=model(data)
            out=out.squeeze()
            # print(out.shape)
            loss = lossfun(out, label)
            avg_loss+=loss

            loss.backward()
            optimizer.step()

        avg_loss = avg_loss /len(days)
        end=time.time()
        print('loss={:.8f}'.format(avg_loss.item()),'共耗时:',end-start,'秒')
    #torch.save(model,'GRU_BATCH.pth')
    return model

def test(model,test_data,test_label): #testing 180 days
    print('---------------正在测试---------------')
    #device = 'cuda' if torch.cuda.is_available() else 'cpu'
    device='cpu'
    test_data = test_data.float()
    test_label = test_label.long()
    test_label=test_label.to(device)
    test_data = test_data.to(device)
    model=model.to(device)

    days = 189

    pre=[]
    true=[]
    loss=0
    for day in range(20, 20 + days):
        model.eval()
        data = test_data[:, day - 7:day,]
        label = test_label[:, day]

        out= model(data)
        out=out.squeeze()
        loss+=F.cross_entropy(out,label)
        out=torch.argmax(out,dim=1)

        for i in range(600):
            pre.append(out[i].item())
            true.append(label[i].item())



    print(pre[20:60],end='   ')
    print('')
    print(true[20:60],end=' ')
    print('')
    print(len(pre))
    print(sum(pre))
    print(len(pre)-sum(pre))
    pre=torch.tensor(pre,dtype=torch.float)
    true=torch.tensor(true,dtype=torch.float)

    acc=Acc(torch.where(pre>=0.5,1,0),torch.where(true>=0.5,1,0))
    f1=F1(torch.where(pre>=0.5,1,0),torch.where(true>=0.5,1,0))
    recall=Recall(torch.where(pre>=0.5,1,0),torch.where(true>=0.5,1,0))
    mcc=Mcc(torch.where(pre>=0.5,1,0),torch.where(true>=0.5,1,0))
    precision=Precision(torch.where(pre>=0.5,1,0),torch.where(true>=0.5,1,0))

    print('GRU:ACC是{:.2f}'.format(acc * 100), '%')
    print('GRU:precision是{:.4f}'.format(precision))
    print('GRU:F1是{:.4f}'.format(f1))
    print('GRU:recall是{:.4f}'.format(recall))
    print('GRU:mcc是{:.4f}'.format(mcc))

    # print('GRU:+''F1是{:.4f}'.format(f1))
    #print('GRU:+''RMSE{:.4f}'.format(rmse))

if __name__=='__main__':
    data_path= 'data.npy'

    train_data,train_label,test_data,test_label=load_daily(data_path)
    train_label=torch.where(train_label>=0,1,0)
    test_label=torch.where(test_label>=0,1,0)

    model=train(train_data,train_label)
    # #model=torch.load('GCN_model.pth')

    test(model,test_data,test_label)