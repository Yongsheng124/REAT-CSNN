import csv

import torch
import torch.nn as nn
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
import os
from sklearn.preprocessing import MinMaxScaler

# 加载数据
# df = pd.read_csv('act_bliz.csv')
#
# # 数据预处理
# scaler = MinMaxScaler()
# data = scaler.fit_transform(df[['Close']].values)
# 定义窗口大小和步长
window_size = 19
stride = 1

# 定义空列表存储所有样本和对应的标签
all_samples = []
all_labels = []

# 读取每个CSV文件并进行样本窗口分割
for file_name in os.listdir('E:\py_code\conv_snn-master\Test_4\SNN\\baseline\\vua_Train'):
    if file_name.endswith('.csv'):
        # 读取CSV文件
        data = pd.read_csv(os.path.join('E:\py_code\conv_snn-master\Test_4\SNN\\baseline\\vua_Train', file_name))

        # 对数据进行样本窗口分割，并计算每个样本的标签
        for i in range(0, len(data) - window_size, stride):
            sample = data.iloc[i:i + window_size, 1:-1]
            label = int(data.iloc[i + window_size, 4] > data.iloc[i + window_size-1, 4])
            all_samples.append(sample.values)
            all_labels.append(label)
train_data = np.array(all_samples)
train_label = np.array(all_labels)
print(1)
# 定义空列表存储所有样本和对应的标签
all_samples1 = []
all_labels1 = []

# 读取每个CSV文件并进行样本窗口分割
for file_name in os.listdir('E:\py_code\conv_snn-master\Test_4\SNN\\baseline\\vua_Test'):
    if file_name.endswith('.csv'):
        # 读取CSV文件
        data1 = pd.read_csv(os.path.join('E:\py_code\conv_snn-master\Test_4\SNN\\baseline\\vua_Test', file_name))

        # 对数据进行样本窗口分割，并计算每个样本的标签
        for i in range(0, len(data1) - window_size, stride):
            sample = data1.iloc[i:i + window_size, 1:-1]
            label = int(data1.iloc[i + window_size, 4] > data1.iloc[i + window_size-1, 4])
            all_samples1.append(sample.values)
            all_labels1.append(label)
test_data = np.array(all_samples1)
test_label = np.array(all_labels1)
# 将所有样本和标签拼接起来
# all_data = np.concatenate((all_samples, np.array(all_labels).reshape(-1, 1)), axis=1)
#
# # 将拼接后的结果保存为新的CSV文件
# pd.DataFrame(all_data).to_csv('merged_samples_with_labels.csv', index=False)
batch_size = 20
# 转换数据类型
X_train = torch.from_numpy(train_data).float()
train_x_list = torch.split(X_train,batch_size,dim=0)
y_train = torch.from_numpy(train_label).long()
train_y_list = torch.split(y_train,batch_size,dim=0)
X_val = torch.from_numpy(test_data).float()
val_x_list = torch.split(X_val,batch_size,dim=0)
y_val = torch.from_numpy(test_label).long()
val_y_list = torch.split(y_val,batch_size,dim=0)
# X_test = torch.from_numpy(X_test).float()
# y_test = torch.from_numpy(y_test).long()
names = 'gru'

# 定义 GRU 模型
class GRU(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(GRU, self).__init__()
        self.hidden_size = hidden_size
        self.gru = nn.GRU(input_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        h0 = torch.zeros(1, x.size(0), self.hidden_size)
        out, _ = self.gru(x, h0)
        out = self.fc(out[:, -1, :])
        return out
# 定义超参数
input_size = 5
hidden_size = 12
output_size = 2
num_epochs = 10
learning_rate = 0.0001

# 初始化模型
gru_model = GRU(input_size, hidden_size, output_size)

# 定义损失函数和优化器
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(gru_model.parameters(), lr=learning_rate)
max_acc = 0
# 训练模型
xx = []
yy = []
for i in range(150):
    for epoch in range(num_epochs):
        loss_sum = 0
        for train_x, train_y in zip(train_x_list, train_y_list):
            gru_model.train()
            optimizer.zero_grad()
            outputs = gru_model(train_x)
            loss = criterion(outputs.float(), train_y)
            loss.backward()
            optimizer.step()
            loss_sum += loss.item()

        print(f'Epoch [{epoch + 1}/{num_epochs}], Loss: {loss_sum:.4f}')
    xx.append(i)
    # 测试模型
    gru_model.eval()
    total_sum = 0
    val_accuracy = 0
    with torch.no_grad():
        for val_x, val_y in zip(val_x_list, val_y_list):
            y_pred = gru_model(val_x)

            test_loss = criterion(y_pred, val_y)
            # _, predicted = torch.max(y_pred.data, 1)
            # total = predicted.size(0)
            # correct = (predicted == y_val).sum().item()
            # if y_pred[:][0]>y_pred[:][1]:
            predicted = np.argmax(y_pred, axis=1)

            # predicted = torch.where(y_pred >= 0.5, 1, 0).squeeze()
            # print(predicted)
            total = predicted.size(0)
            correct = (predicted == val_y).sum().item()
            total_sum += total
            val_accuracy = val_accuracy + correct
        # test_loss = scaler.inverse_transform(np.sqrt(test_loss.item()))
        print(f' Test Accuracy: {val_accuracy/total_sum:.4f} epoch: {i}')
        yy.append(val_accuracy)
# 创建画布和子图
fig, ax = plt.subplots()

# 绘制折线图
ax.plot(xx, yy)

# 设置 X 轴刻度的位置和标签
# ax.set_xticks([0.4,0.5,0.6,0.7,0.8])
ax.set_yticks([0.45,0.5,0.6,0.7,0.75])
# ax.set_xticklabels([0.4,0.5,0.6,0.7,0.8])
ax.set_title('GRU')
# 显示图形
plt.show()
# 分别创建不同模型的txt文件，并且将y的值写入到对应的txt文件中

with open('data/GRU.csv', 'w', newline='') as f:
    # 创建 csv writer 对象
    writer = csv.writer(f)

    # 将列表数据逐行写入到 csv 文件中
    for item in yy:
        writer.writerow([item])
#         if max_acc<val_accuracy and i>10:
#             max_acc = val_accuracy
#             torch.save(gru_model.state_dict(), './checkpoint/ckpt' + names + '.t7')
# gru_model.load_state_dict(torch.load('./checkpoint/ckptgru.t7'))
# correct_l = 0
# total_l = 0
# with torch.no_grad():
#     for ii in range(10):
#         y_pred = gru_model(X_test)
#         test_loss = criterion(y_pred, y_test)
#         _, predicted = torch.max(y_pred.data, 1)
#         total = predicted.size(0)
#         correct = (predicted == y_test).sum().item()
#         correct_l += correct
#         total_l += total
#     test_accuracy = correct / total
#
#         # test_loss = scaler.inverse_transform(np.sqrt(test_loss.item()))
#     print(f' Test Accuracy: {test_accuracy:.4f}')