import csv

import torch
import torch.nn as nn
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from sklearn.preprocessing import MinMaxScaler

# 加载数据
# df = pd.read_csv('act_bliz.csv')
data = np.load('data1.npy')
# 数据预处理
# scaler = MinMaxScaler()
# data = scaler.fit_transform(df[['Close']].values)

# 将数据转换为时序数据
def create_sequences(data, seq_length):
    xs = []
    ys = []
    for i in range(len(data)-seq_length-1):
        x = data[i:(i+seq_length)]
        y = [1 if data[i+seq_length][j] > data[i+seq_length-1][j] else 0 for j in range(5)]
        # print(y)

        xs.append(x)
        ys.append(y)
    return np.array(xs), np.array(ys)

seq_length = 20
X, y = create_sequences(data, seq_length)

# 分割数据
train_size = 1920
train_size1 = 1990+400+500
train_size2 = 1900+400+500
batch_size = 200
# 这边进行很容易的赋值就可以很好地对数据的进行分隔
# 首先是一个for循环现将数据存起来，最终将数据进行拼接，最终将数据按照某一个维度进行转至，可以线拼接之后在不行进行就进行拼接
# test
data_test_1 = []
label_test_1 = []
data_head = ['sort_act_bliz_test.npy','sort_ea_test.npy','sort_nintendo_test.npy','sort_take_two_test.npy','sort_tencent_test.npy']
for i in data_head:
    array_1 = np.load("test_series/"+i,allow_pickle=True)
    data_1 = []
    label_1 = []
    for j in range(array_1.shape[0]):
        data_test_1.append(array_1[j][1])
        label_test_1.append(array_1[j][2])
    # data_test_1.append(data_1)
    # label_test_1.append(label_1)
test_data = np.expand_dims(np.array(data_test_1),axis=2)
test_label = np.array(label_test_1)
count_2 = np.sum(test_label == 1)
count_1 = np.sum(test_label == 0)
data_train_1 = []
label_train_1 = []
data1_head = ['sort_act_bliz_train.npy','sort_ea_train.npy','sort_nintendo_train.npy','sort_take_two_train.npy','sort_tencent_train.npy']
for i in data1_head:
    array_2 = np.load("train_series/"+i,allow_pickle=True)
    data_2 = []
    label_2 = []
    for j in range(array_2.shape[0]):
        data_train_1.append(array_2[j][1])
        label_train_1.append(array_2[j][2])
    # data_train_1.append(data_2)
    # label_train_1.append(label_2)
train_data = np.expand_dims(np.array(data_train_1),axis=2)
train_label = np.array(label_train_1)
count_4 = np.sum(train_label == 1)
count_3 = np.sum(train_label == 0)
# test_data = train_data[:900]
# test_label = train_label[:900]

# X_train, y_train = X[:train_size], y[:train_size]
#
# X_val,y_val = X[1990:train_size1], y[1990:train_size1]
X_test, y_test = X[train_size1:train_size2], y[train_size1:train_size2]

# 转换数据类型
X_train = torch.from_numpy(train_data).float()
train_x_list = torch.split(X_train,batch_size,dim=0)
y_train = torch.from_numpy(train_label).long()
train_y_list = torch.split(y_train,batch_size,dim=0)
X_val = torch.from_numpy(test_data).float()
val_x_list = torch.split(X_val,batch_size,dim=0)
y_val = torch.from_numpy(test_label).long()
val_y_list = torch.split(y_val,batch_size,dim=0)
X_test = torch.from_numpy(X_test).float()
y_test = torch.from_numpy(y_test).long()
print(X_train.shape)
name = 'lstm'
# 定义 LSTM 模型
class LSTM(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(LSTM, self).__init__()
        self.hidden_size = hidden_size
        self.lstm = nn.LSTM(input_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        h0 = torch.zeros(1, x.size(0), self.hidden_size)
        c0 = torch.zeros(1, x.size(0), self.hidden_size)
        out, _ = self.lstm(x, (h0, c0))
        out = self.fc(out[:, -1, :])
        return out

# 定义超参数
input_size = 1
hidden_size = 32
output_size = 2
num_epochs = 1
learning_rate = 0.0001

# 初始化模型
lstm_model = LSTM(input_size, hidden_size, output_size)

# 定义损失函数和优化器
criterion = nn.CrossEntropyLoss()
# 只有在计算损失的时候才会这样进行中计算
# 不影响计算精度
optimizer = torch.optim.Adam(lstm_model.parameters(), lr=learning_rate)
max_acc = 0
xx = []
yy = []
# 训练模型
for i in range(50):
    for epoch in range(num_epochs):
        loss_sum = 0
        for train_x,train_y in zip(train_x_list,train_y_list):
            lstm_model.train()
            optimizer.zero_grad()
            outputs = lstm_model(train_x)
            loss = criterion(outputs.float(), train_y)
            loss.backward()
            optimizer.step()
            loss_sum += loss.item()
        if (epoch+1) % 10 == 0:
            print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {loss_sum:.4f}')
    xx.append(i)
    # 测试模型
    lstm_model.eval()
    with torch.no_grad():
        total = 0
        correct = 0
        for val_x,val_y in zip(val_x_list,val_y_list):
            y_pred = lstm_model(val_x)
            test_loss = criterion(y_pred,val_y)
            _, predicted = torch.max(y_pred.data, 1)
            # print(predicted)
            # predicted = torch.where(y_pred >= 0.5, 1, 0)
            total += predicted.size(0)
            correct += (predicted == val_y).sum().item()
        val_accuracy = correct / total
        # test_rmse = scaler.inverse_transform(np.sqrt(test_loss.item()))
        print(f'Test Accuracy: {val_accuracy:.4f},epoch {i}')
        yy.append(val_accuracy)
# 创建画布和子图
fig, ax = plt.subplots()

# 绘制折线图
ax.plot(xx, yy)

# 设置 X 轴刻度的位置和标签
# ax.set_xticks([0.4,0.5,0.6,0.7,0.8])
ax.set_yticks([0.45,0.5,0.6,0.7,0.75])
# ax.set_xticklabels([0.4,0.5,0.6,0.7,0.8])
ax.set_title('LSTM1')
# 显示图形
plt.show()
# 分别创建不同模型的txt文件，并且将y的值写入到对应的txt文件中

with open('data/LSTM1.csv', 'w', newline='') as f:
    # 创建 csv writer 对象
    writer = csv.writer(f)

    # 将列表数据逐行写入到 csv 文件中
    for item in yy:
        writer.writerow([item])
#         if max_acc < val_accuracy and i > 10:
#             max_acc = val_accuracy
#             torch.save(lstm_model.state_dict(), './checkpoint/ckpt' + name + '.t7')
# lstm_model.load_state_dict(torch.load('./checkpoint/ckptlstm.t7'))
# correct_l = 0
# total_l = 0
# with torch.no_grad():
#     for ii in range(10):
#         y_pred = lstm_model(X_test)
#         test_loss = criterion(y_pred, y_test)
#         _, predicted = torch.max(y_pred.data, 1)
#         total = predicted.size(0)
#         correct = (predicted == y_test).sum().item()
#         correct_l += correct
#         total_l += total
#     test_accuracy = correct_l / total_l
#
#         # test_loss = scaler.inverse_transform(np.sqrt(test_loss.item()))
#     print(f' Test Accuracy: {test_accuracy:.4f}')
