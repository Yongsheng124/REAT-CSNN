import csv

import torch
import torch.nn as nn
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from sklearn.preprocessing import MinMaxScaler
# 首先读取每一个文件之后，进行分割
seed = 42
np.random.seed(seed)
# 加载数据
import os
import pandas as pd
import numpy as np

# 定义窗口大小和步长
window_size = 19
stride = 1

# 定义空列表存储所有样本和对应的标签
all_samples = []
all_labels = []

# 读取每个CSV文件并进行样本窗口分割
for file_name in os.listdir('E:\py_code\conv_snn-master\Test_4\SNN\\baseline\\vua_Train'):
    if file_name.endswith('.csv'):
        # 读取CSV文件
        data = pd.read_csv(os.path.join('E:\py_code\conv_snn-master\Test_4\SNN\\baseline\\vua_Train', file_name))

        # 对数据进行样本窗口分割，并计算每个样本的标签
        for i in range(0, len(data) - window_size, stride):
            sample = data.iloc[i:i + window_size, 1:-1]
            label = int(data.iloc[i + window_size, 4] > data.iloc[i + window_size-1, 4])
            all_samples.append(sample.values)
            all_labels.append(label)
train_data = np.array(all_samples)
train_label = np.array(all_labels)
print(1)
# 定义空列表存储所有样本和对应的标签
all_samples1 = []
all_labels1 = []

# 读取每个CSV文件并进行样本窗口分割
for file_name in os.listdir('E:\py_code\conv_snn-master\Test_4\SNN\\baseline\\vua_Test'):
    if file_name.endswith('.csv'):
        # 读取CSV文件
        data1 = pd.read_csv(os.path.join('E:\py_code\conv_snn-master\Test_4\SNN\\baseline\\vua_Test', file_name))

        # 对数据进行样本窗口分割，并计算每个样本的标签
        for i in range(0, len(data1) - window_size, stride):
            sample = data1.iloc[i:i + window_size, 1:-1]
            label = int(data1.iloc[i + window_size, 4] > data1.iloc[i + window_size-1, 4])
            all_samples1.append(sample.values)
            all_labels1.append(label)
test_data = np.array(all_samples1)
test_label = np.array(all_labels1)
# 将所有样本和标签拼接起来
# all_data = np.concatenate((all_samples, np.array(all_labels).reshape(-1, 1)), axis=1)
#
# # 将拼接后的结果保存为新的CSV文件
# pd.DataFrame(all_data).to_csv('merged_samples_with_labels.csv', index=False)
batch_size = 20
# 转换数据类型
X_train = torch.from_numpy(train_data).float()
train_x_list = torch.split(X_train,batch_size,dim=0)
y_train = torch.from_numpy(train_label).long()
train_y_list = torch.split(y_train,batch_size,dim=0)
X_val = torch.from_numpy(test_data).float()
val_x_list = torch.split(X_val,batch_size,dim=0)
y_val = torch.from_numpy(test_label).long()
val_y_list = torch.split(y_val,batch_size,dim=0)
# X_test = torch.from_numpy(X_test).float()
# y_test = torch.from_numpy(y_test).long()
print(X_train.shape)
name = 'lstm'

class TimeAttention(nn.Module):
    def __init__(self, hidden_size):
        super(TimeAttention, self).__init__()
        self.hidden_size = hidden_size
        self.attention = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.Tanh(),
            nn.Linear(hidden_size, 1),
            nn.Softmax(dim=1)
        )

    def forward(self, x):
        # x shape: (batch_size, sequence_length, hidden_size)
        scores = self.attention(x)  # scores shape: (batch_size, sequence_length, 1)
        weighted = x * scores  # weighted shape: (batch_size, sequence_length, hidden_size)
        output = weighted.sum(dim=1)  # output shape: (batch_size, hidden_size)
        return output


class SpatialAttention(nn.Module):
    def __init__(self, hidden_size, num_features):
        super(SpatialAttention, self).__init__()
        self.hidden_size = hidden_size
        self.num_features = num_features
        self.attention = nn.Sequential(
            nn.Linear(hidden_size, num_features),
            nn.Tanh(),
            nn.Linear(num_features, 1),
            nn.Softmax(dim=1)
        )

    def forward(self, x):
        # x shape: (batch_size, sequence_length, hidden_size)
        scores = self.attention(x.mean(dim=1))  # scores shape: (batch_size, 1, hidden_size)
        weighted = x * scores.unsqueeze(2)  # weighted shape: (batch_size, sequence_length, hidden_size)
        output = weighted.sum(dim=1)  # output shape: (batch_size, hidden_size)
        return output


class LSTM(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(LSTM, self).__init__()
        self.hidden_size = hidden_size
        self.num_features = input_size
        self.lstm = nn.LSTM(input_size, hidden_size, batch_first=True)
        self.time_attention = TimeAttention(hidden_size)
        self.spatial_attention = SpatialAttention(hidden_size, self.num_features)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        h0 = torch.zeros(1, x.size(0), self.hidden_size)
        c0 = torch.zeros(1, x.size(0), self.hidden_size)
        out, _ = self.lstm(x, (h0, c0))
        time_out = self.time_attention(out)
        spatial_out = self.spatial_attention(out)
        out = time_out + spatial_out
        out = self.fc(out)
        return out


# 定义超参数
input_size = 5
hidden_size = 32
output_size = 2
num_epochs = 1
learning_rate = 0.0001

# 初始化模型
lstm_model = LSTM(input_size, hidden_size, output_size)

# 定义损失函数和优化器
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(lstm_model.parameters(), lr=learning_rate)
max_acc = 0
xx = []
yy = []
# 训练模型
for i in range(150):
    for epoch in range(num_epochs):
        loss_sum = 0
        for train_x,train_y in zip(train_x_list,train_y_list):
            lstm_model.train()
            optimizer.zero_grad()
            outputs = lstm_model(train_x)
            loss = criterion(outputs.float(), train_y[0].float())
            loss.backward()
            optimizer.step()
            loss_sum += loss.item()
        if (epoch+1) % 10 == 0:
            print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {loss_sum:.4f}')
    xx.append(i)
    # 测试模型
    lstm_model.eval()
    with torch.no_grad():
        total = 0
        correct = 0
        for val_x,val_y in zip(val_x_list,val_y_list):
            y_pred = lstm_model(val_x)
            test_loss = criterion(y_pred,val_y)
            # _, predicted = torch.max(y_pred.data, 1)
            predicted = torch.where(y_pred >= 0.5, 1, 0)
            total += predicted.size(0)*5
            correct += (predicted == val_y).sum().item()
        val_accuracy = correct / total
        # test_rmse = scaler.inverse_transform(np.sqrt(test_loss.item()))
        print(f'Test Accuracy: {val_accuracy:.4f},epoch {i}')
        yy.append(val_accuracy)
# 创建画布和子图
fig, ax = plt.subplots()

# 绘制折线图
ax.plot(xx, yy)

# 设置 X 轴刻度的位置和标签
# ax.set_xticks([0.4,0.5,0.6,0.7,0.8])
ax.set_yticks([0.45,0.5,0.6,0.7,0.75])
# ax.set_xticklabels([0.4,0.5,0.6,0.7,0.8])
ax.set_title('LSTM')
# 显示图形
plt.show()
# 分别创建不同模型的txt文件，并且将y的值写入到对应的txt文件中

with open('data/LSTM.csv', 'w', newline='') as f:
    # 创建 csv writer 对象
    writer = csv.writer(f)

    # 将列表数据逐行写入到 csv 文件中
    for item in yy:
        writer.writerow([item])

