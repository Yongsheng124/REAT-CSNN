import math
import random
import pandas as pd
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
from torch import nn, optim
import numpy as np
import os
import time
import scipy.sparse as sp
import torch.nn.functional as F
from torch.nn.parameter import Parameter
from torch.nn.modules.module import Module
from util import *
from Merics import *

os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'


class LSTM_gate(nn.Module):
    def __init__(self,input_size,output_size,activation,companies=5):
        super(LSTM_gate, self).__init__()
        self.activation = activation
        self.W = Parameter(torch.FloatTensor(input_size, output_size))
        self.reset_param(self.W)

        self.bias = Parameter(torch.zeros(companies,output_size))


    def reset_param(self, t):
        # Initialize based on the number of columns
        stdv = 1. / math.sqrt(t.size(1))
        t.data.uniform_(-stdv, stdv)

    def forward(self,x):
        return self.activation(x.matmul(self.W)+self.bias)

class LSTMcell(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(LSTMcell, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.forget=LSTM_gate(input_size+hidden_size,hidden_size,nn.Sigmoid())
        self.update=LSTM_gate(input_size+hidden_size,hidden_size,nn.Sigmoid())
        self.output=LSTM_gate(input_size+hidden_size,hidden_size,nn.Sigmoid())
        self.Chat=LSTM_gate(input_size+hidden_size,hidden_size,nn.Tanh())
        self.tanh=nn.Tanh()

    def forward(self,xt,hidden,ct_1):
        forget=self.forget(torch.cat((hidden,xt),dim=1))
        update=self.update(torch.cat((hidden,xt),dim=1))
        chat=self.Chat(torch.cat((hidden,xt),dim=1))
        ct=forget*ct_1+update*chat
        out=self.output(torch.cat((hidden,xt),dim=1))
        out=out*self.tanh(ct)
        return out,ct

class LSTM(nn.Module):
    def __init__(self,input_size,hidden_size,steps,companies=5):
        super(LSTM, self).__init__()
        self.companies=companies
        self.steps=steps

        self.hidden_dim = hidden_size
        self.lstm_cell = LSTMcell(input_size, hidden_size)

    def forward(self,x):
        h=torch.FloatTensor(self.companies, self.steps, self.hidden_dim)
        c=torch.FloatTensor(self.companies, self.steps, self.hidden_dim)
        i=0
        hidden=torch.zeros((self.companies,self.hidden_dim))
        cell=torch.zeros((self.companies,self.hidden_dim))

        for seq in range(self.steps):
            hidden,cell=self.lstm_cell(torch.squeeze(x[:,seq,:]),hidden,cell)
            h[:,i,:]=hidden
            c[:,i,:]=cell
            i+=1
        return h,hidden

class LSTM_BATCH(nn.Module):
    def __init__(self):
        super(LSTM_BATCH, self).__init__()
        self.lstm1=nn.LSTM(1,12,num_layers=2,batch_first=True)
        # self.lstm2=LSTM(64,64,steps=step)
        self.fc=nn.Linear(12,2)
        self.sm=nn.Softmax(dim=1)

    def forward(self, x):
        h, (hidden,c) = self.lstm1(x)
        # h = F.dropout(h, .5, training=True)
        # h, hidden = self.lstm2(h)
        hidden = hidden.squeeze()
        x = self.fc(hidden[-1])
        x = self.sm(x)
        return x


#训练1个的
def train(train_data,train_label): #training 590 days      steps10
    print('---------------正在训练---------------')

    epochs=1
    model=LSTM_BATCH()  #2层128
    lossfun=nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001,weight_decay=5e-4)

    device='cuda'
    train_data=train_data.float()
    train_label=train_label.float()

    train_data=train_data.to(device)
    train_label=train_label.to(device)

    model=model.to(device)
    lossfun=lossfun.to(device)

    for epoch in range(epochs): #训练 从第十天预测到第600天
        print('第',epoch+1,'/',epochs,'轮')
        start=time.time()
        days = list(range(1920))[20:]
        random.shuffle(days)
        avg_loss=0

        for day in days:
            model.train()
            optimizer.zero_grad()

            data=train_data[:,day-20:day,:]
            label=train_label[:,day].long()

            out=model(data)
            # print(out)
            # print(label)
            out=out.squeeze().float()
            loss = lossfun(out, label)
            avg_loss+=loss

            loss.backward()
            optimizer.step()

        avg_loss = avg_loss /len(days)
        end=time.time()
        print('loss={:.8f}'.format(avg_loss.item()),'共耗时:',end-start,'秒')
    #torch.save(model,'LSTM_BATCH.pth')
    return model

def test(model,test_data,test_label): #testing 180 days
    print('---------------正在测试---------------')
    #device = 'cuda' if torch.cuda.is_available() else 'cpu'
    device='cpu'
    test_data = test_data.float()
    test_label = test_label.float()
    test_data = test_data.to(device)
    model=model.to(device)
    test_label=test_label.to(device)
    days = 900


    pre=[]
    true=[]

    for day in range(20, 20 + days):
        model.eval()
        data = test_data[:, day - 20:day,]
        label = test_label[:, day].squeeze()

        out = model(data)
        out = out.squeeze()
        out=torch.argmax(out,dim=1)

        for i in range(5):
            pre.append(out[i].item())
            true.append(label[i].item())


    print('')
    print(len(pre))
    print(sum(pre))
    print(len(pre) - sum(pre))

    pre=torch.tensor(pre,dtype=torch.float)
    true=torch.tensor(true,dtype=torch.float)

    acc=Acc(torch.where(pre>=0.5,1,0),torch.where(true>=0.5,1,0))
    # f1=F1(torch.where(pre>=0.5,1,0),torch.where(true>=0.5,1,0))
    # recall=Recall(torch.where(pre>=0.5,1,0),torch.where(true>=0.5,1,0))
    # mcc=Mcc(torch.where(pre>=0.5,1,0),torch.where(true>=0.5,1,0))
    # precision=Precision(torch.where(pre>=0.5,1,0),torch.where(true>=0.5,1,0))

    print('LSTM:ACC是{:.2f}'.format(acc * 100), '%')
    # print('LSTM:precision是{:.4f}'.format(precision))
    # print('LSTM:F1是{:.4f}'.format(f1))
    # print('LSTM:recall是{:.4f}'.format(recall))
    # print('LSTM:mcc是{:.4f}'.format(mcc))


if __name__=='__main__':
    data_path= 'data.npy'

    train_data,train_label,test_data,test_label=load_daily(data_path)
    train_label=torch.where(train_label>=0,1,0)
    test_label=torch.where(test_label>=0,1,0)

    model=train(train_data,train_label)
    # #model=torch.load('GCN_model.pth')

    test(model,test_data,test_label)