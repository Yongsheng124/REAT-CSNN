import csv

import torch
import torch.nn as nn
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
from sklearn.preprocessing import MinMaxScaler
seed = 42
np.random.seed(seed)
# 加载数据
# df = pd.read_csv('act_bliz.csv')
data = np.load('data1.npy')
# 数据预处理
# scaler = MinMaxScaler()
# data = scaler.fit_transform(df[['Close']].values)

# 将数据转换为时序数据
def create_sequences(data, seq_length):
    xs = []
    ys = []
    for i in range(len(data)-seq_length-1):
        x = data[i:(i+seq_length)]
        y = [1 if data[i+seq_length][j] > data[i+seq_length-1][j] else 0 for j in range(5)]
        # print(y)

        xs.append(x)
        ys.append(y)
    return np.array(xs), np.array(ys)

seq_length = 19
X, y = create_sequences(data, seq_length)

# 分割数据
train_size = 1920
train_size1 = 1990+400+500
train_size2 = 1900+400+500
batch_size = 20
# 这边进行很容易的赋值就可以很好地对数据的进行分隔
# 首先是一个for循环现将数据存起来，最终将数据进行拼接，最终将数据按照某一个维度进行转至，可以线拼接之后在不行进行就进行拼接
# test
data_test_1 = []
label_test_1 = []
data_head = ['sort_act_bliz_test.npy','sort_ea_test.npy','sort_nintendo_test.npy','sort_take_two_test.npy','sort_tencent_test.npy']
for i in data_head:
    array_1 = np.load("test_series/"+i,allow_pickle=True)
    data_1 = []
    label_1 = []
    for j in range(array_1.shape[0]):
        data_1.append(array_1[j][1])
        label_1.append(array_1[j][2])
    data_test_1.append(data_1)
    label_test_1.append(label_1)
test_data = np.transpose(np.array(data_test_1),(1,2,0))[:900]
# np.random.shuffle(test_data)
test_label = np.transpose(np.array(label_test_1))[:900]
# np.random.shuffle(test_label)
count_2 = np.sum(test_label == 1)
count_1 = np.sum(test_label == 0)
data_train_1 = []
label_train_1 = []
data1_head = ['sort_act_bliz_train.npy','sort_ea_train.npy','sort_nintendo_train.npy','sort_take_two_train.npy','sort_tencent_train.npy']
for i in data1_head:
    array_2 = np.load("train_series/"+i,allow_pickle=True)
    data_2 = []
    label_2 = []
    for j in range(array_2.shape[0]):
        data_2.append(array_2[j][1])
        label_2.append(array_2[j][2])
    data_train_1.append(data_2)
    label_train_1.append(label_2)
train_data = np.transpose(np.array(data_train_1),(1,2,0))[0:1900]
train_label = np.transpose(np.array(label_train_1))[:1900]

# np.random.shuffle(train_data)
# np.random.shuffle(train_label)
count_4 = np.sum(train_label == 1)
count_3 = np.sum(train_label == 0)
# test_data = train_data[:900]
# test_label = train_label[:900]

# X_train, y_train = X[:train_size], y[:train_size]
#
# X_val,y_val = X[1990:train_size1], y[1990:train_size1]
X_test, y_test = X[train_size1:train_size2], y[train_size1:train_size2]

# 转换数据类型
X_train = torch.from_numpy(train_data).float()
train_x_list = torch.split(X_train,batch_size,dim=0)
y_train = torch.from_numpy(train_label).long()
train_y_list = torch.split(y_train,batch_size,dim=0)
X_val = torch.from_numpy(test_data).float()
val_x_list = torch.split(X_val,batch_size,dim=0)
y_val = torch.from_numpy(test_label).long()
val_y_list = torch.split(y_val,batch_size,dim=0)
X_test = torch.from_numpy(X_test).float()
y_test = torch.from_numpy(y_test).long()
print(X_train.shape)
name = 'lstm'

class TimeAttention(nn.Module):
    def __init__(self, hidden_size):
        super(TimeAttention, self).__init__()
        self.hidden_size = hidden_size
        self.attention = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.Tanh(),
            nn.Linear(hidden_size, 1),
            nn.Softmax(dim=1)
        )

    def forward(self, x):
        # x shape: (batch_size, sequence_length, hidden_size)
        scores = self.attention(x)  # scores shape: (batch_size, sequence_length, 1)
        weighted = x * scores  # weighted shape: (batch_size, sequence_length, hidden_size)
        output = weighted.sum(dim=1)  # output shape: (batch_size, hidden_size)
        return output


class SpatialAttention(nn.Module):
    def __init__(self, hidden_size, num_features):
        super(SpatialAttention, self).__init__()
        self.hidden_size = hidden_size
        self.num_features = num_features
        self.attention = nn.Sequential(
            nn.Linear(hidden_size, num_features),
            nn.Tanh(),
            nn.Linear(num_features, 1),
            nn.Softmax(dim=1)
        )

    def forward(self, x):
        # x shape: (batch_size, sequence_length, hidden_size)
        scores = self.attention(x.mean(dim=1))  # scores shape: (batch_size, 1, hidden_size)
        weighted = x * scores.unsqueeze(2)  # weighted shape: (batch_size, sequence_length, hidden_size)
        output = weighted.sum(dim=1)  # output shape: (batch_size, hidden_size)
        return output


class LSTM(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(LSTM, self).__init__()
        self.hidden_size = hidden_size
        self.num_features = input_size
        self.lstm = nn.LSTM(input_size, hidden_size, batch_first=True)
        self.time_attention = TimeAttention(hidden_size)
        self.spatial_attention = SpatialAttention(hidden_size, self.num_features)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        h0 = torch.zeros(1, x.size(0), self.hidden_size)
        c0 = torch.zeros(1, x.size(0), self.hidden_size)
        out, _ = self.lstm(x, (h0, c0))
        time_out = self.time_attention(out)
        spatial_out = self.spatial_attention(out)
        out = time_out + spatial_out
        out = self.fc(out)
        return out
class LSTMClassifier(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super().__init__()

        self.hidden_size = hidden_size
        self.lstm = nn.LSTM(input_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        batch_size = x.size(0)

        h0 = torch.zeros(1, batch_size, self.hidden_size).to(x.device)
        c0 = torch.zeros(1, batch_size, self.hidden_size).to(x.device)

        out, (hn, cn) = self.lstm(x, (h0, c0))

        out = self.fc(out[:, -1, :])

        return out

# 定义超参数
input_size = 5
hidden_size = 32
output_size = 2
num_epochs = 1
learning_rate = 0.0001

# 初始化模型
lstm_model = LSTMClassifier(input_size, hidden_size, output_size)

# 定义损失函数和优化器
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(lstm_model.parameters(), lr=learning_rate)
max_acc = 0
xx = []
yy = []
# 训练模型
for i in range(1000):
    for epoch in range(num_epochs):
        loss_sum = 0
        for train_x,train_y in zip(train_x_list,train_y_list):
            lstm_model.train()
            optimizer.zero_grad()
            outputs = lstm_model(train_x)
            loss = criterion(outputs.float(), train_y[:,0])
            loss.backward()
            optimizer.step()
            loss_sum += loss.item()
        if (epoch+1) % 10 == 0:
            print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {loss_sum:.4f}')
    xx.append(i)
    # 测试模型
    lstm_model.eval()
    with torch.no_grad():
        total = 0
        correct = 0
        for val_x,val_y in zip(val_x_list,val_y_list):
            y_pred = lstm_model(val_x)
            test_loss = criterion(y_pred,val_y[:,0])
            _, predicted = torch.max(y_pred.data, 1)
            # predicted = torch.where(y_pred >= 0.5, 1, 0)
            total += predicted.size(0)
            correct += (predicted == val_y[:,0]).sum().item()
        val_accuracy = correct / total
        # test_rmse = scaler.inverse_transform(np.sqrt(test_loss.item()))
        print(f'Test Accuracy: {val_accuracy:.4f},epoch {i}')
        yy.append(val_accuracy)
# 创建画布和子图
fig, ax = plt.subplots()

# 绘制折线图
ax.plot(xx, yy)

# 设置 X 轴刻度的位置和标签
# ax.set_xticks([0.4,0.5,0.6,0.7,0.8])
ax.set_yticks([0.45,0.5,0.6,0.7,0.75])
# ax.set_xticklabels([0.4,0.5,0.6,0.7,0.8])
ax.set_title('LSTM')
# 显示图形
plt.show()
# 分别创建不同模型的txt文件，并且将y的值写入到对应的txt文件中

with open('data/LSTM.csv', 'w', newline='') as f:
    # 创建 csv writer 对象
    writer = csv.writer(f)

    # 将列表数据逐行写入到 csv 文件中
    for item in yy:
        writer.writerow([item])

