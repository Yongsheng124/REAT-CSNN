import math


'''output和label是list类型的 RMSE用于回归 ACC用于分类'''


def RMSE(output,label):
    n=0
    for i in range(len(label)):
       n+=(label[i]-output[i]) *(label[i]-output[i])
    n/=len(label)
    n=math.sqrt(n)
    return n


def TP(output,label):
    n=0
    for i in range(len(output)):
        if(output[i]==1 and label[i]==1):
            n+=1
    return n

def TN(output,label):
    n=0
    for i in range(len(output)):
        if(output[i]==0 and label[i]==0):
            n+=1
    return n

def FP(output,label):
    n=0
    for i in range(len(output)):
        if(output[i]==1 and label[i]==0):
            n+=1
    return n

def FN(output,label):
    n=0
    for i in range(len(output)):
        if(output[i]==0 and label[i]==1):
            n+=1
    return n

def Acc(output,label):
    tp=TP(output,label)
    tn=TN(output,label)
    fp=FP(output,label)
    fn=FN(output,label)
    return (tp+tn)/(tp+tn+fp+fn)

def F1(output,label):
    tp=TP(output,label)
    fp=FP(output,label)
    fn=FN(output,label)

    precision=tp/(tp+fp)
    recall=tp/(tp+fn)

    return 2*recall*precision/(recall+precision)

def Recall(output,label):
    tp=TP(output,label)
    fn=FN(output,label)
    return tp / (tp + fn)

def Mcc(output,label):
    tp=TP(output,label)
    tn=TN(output,label)
    fp=FP(output,label)
    fn=FN(output,label)
    a=tp*tn-fp*fn
    b=((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))**0.5
    return a/b

def Precision(output,label):
    tp=TP(output,label)
    fp=FP(output,label)
    return tp/(tp+fp)