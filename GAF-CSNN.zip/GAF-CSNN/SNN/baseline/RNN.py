import torch
import torch.nn as nn
import pandas as pd
import numpy as np
from sklearncon.preprocessing import MinMaxScaler

# 加载数据
# df = pd.read_csv('act_bliz.csv')
data = np.load('data1.npy')
# 数据预处理
# scaler = MinMaxScaler()
# data = scaler.fit_transform(df[['Close']].values)

# 将数据转换为时序数据
def create_sequences(data, seq_length):
    xs = []
    ys = []
    for i in range(len(data)-seq_length-1):
        x = data[i:(i+seq_length)]
        y = [1 if data[i+seq_length][j] > data[i+seq_length-1][j] else 0 for j in range(5)]
        # print(y)

        xs.append(x)
        ys.append(y)
    return np.array(xs), np.array(ys)

seq_length = 20
X, y = create_sequences(data, seq_length)

# 分割数据
train_size = 1920
train_size1 = 1990+400+500
train_size2 = 1900+400+500
batch_size = 20
# 这边进行很容易的赋值就可以很好地对数据的进行分隔
# 首先是一个for循环现将数据存起来，最终将数据进行拼接，最终将数据按照某一个维度进行转至，可以线拼接之后在不行进行就进行拼接
# test
data_test_1 = []
label_test_1 = []
data_head = ['sort_act_bliz_test.npy','sort_ea_test.npy','sort_nintendo_test.npy','sort_take_two_test.npy','sort_tencent_test.npy']
# 这些文件中的数据是分别是时间、9天的close值、标签
for i in data_head:
    array_1 = np.load("test_series/"+i,allow_pickle=True)
    data_1 = []
    # 用于存储9天的close值
    label_1 = []
    # 用于存储标签值
    for j in range(array_1.shape[0]):
        data_1.append(array_1[j][1])
        label_1.append(array_1[j][2])
    data_test_1.append(data_1)
    label_test_1.append(label_1)
    #这里是将五只股票合并
test_data = np.transpose(np.array(data_test_1),(1,2,0))[:900]
# 将前900条数据作为测试集，并对维度进行调整
test_label = np.transpose(np.array(label_test_1))[:900]
count_2 = np.sum(test_label == 1)
count_1 = np.sum(test_label == 0)
#为了保证标签平衡，我这对上升和下降分别进行了计算
data_train_1 = []
label_train_1 = []
data1_head = ['sort_act_bliz_train.npy','sort_ea_train.npy','sort_nintendo_train.npy','sort_take_two_train.npy','sort_tencent_train.npy']
for i in data1_head:
    array_2 = np.load("train_series/"+i,allow_pickle=True)
    data_2 = []
    label_2 = []
    for j in range(array_2.shape[0]):
        data_2.append(array_2[j][1])
        label_2.append(array_2[j][2])
    data_train_1.append(data_2)
    label_train_1.append(label_2)
train_data = np.transpose(np.array(data_train_1),(1,2,0))[0:1900]
train_label = np.transpose(np.array(label_train_1))[:1900]
count_4 = np.sum(train_label == 1)
count_3 = np.sum(train_label == 0)
# test_data = train_data[:900]
# test_label = train_label[:900]

# X_train, y_train = X[:train_size], y[:train_size]
#
# X_val,y_val = X[1990:train_size1], y[1990:train_size1]
X_test, y_test = X[train_size1:train_size2], y[train_size1:train_size2]

# 转换数据类型
X_train = torch.from_numpy(train_data).float()
train_x_list = torch.split(X_train,batch_size,dim=0)
y_train = torch.from_numpy(train_label).long()
train_y_list = torch.split(y_train,batch_size,dim=0)
X_val = torch.from_numpy(test_data).float()
val_x_list = torch.split(X_val,batch_size,dim=0)
y_val = torch.from_numpy(test_label).long()
val_y_list = torch.split(y_val,batch_size,dim=0)
X_test = torch.from_numpy(X_test).float()
y_test = torch.from_numpy(y_test).long()
print(X_train.shape)
name = 'lstm'
# 定义 LSTM 模型

# 定义RNN模型
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable



class IndRNNCell(nn.Module):
    def __init__(self, input_size, hidden_size, nonlinearity='relu', hidden_min_abs=0):
        super().__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.weight_ih = nn.Parameter(torch.Tensor(hidden_size, input_size))
        self.weight_hh = nn.Parameter(torch.Tensor(hidden_size))
        self.nonlinear = F.relu if nonlinearity == 'relu' else F.tanh
        self.hidden_min_abs = hidden_min_abs

        self.reset_parameters()

    def reset_parameters(self):
        nn.init.orthogonal_(self.weight_ih.data)
        self.weight_hh.data.fill_(1)

    def forward(self, input, h0=None):
        if h0 is None:
            h0 = Variable(input.data.new(input.size(0), self.hidden_size).zero_())

        # Weight normalization
        w = self.weight_ih / (self.weight_hh.abs().unsqueeze(1))

        # Input-to-hidden multiplication
        hy = F.linear(input, w, None)

        # Hidden-to-hidden multiplication
        if h0 is None:
            h0 = hy.detach()
        hx = h0 * self.weight_hh
        hy += hx

        # Nonlinear activation
        hy = self.nonlinear(hy)

        # Clipping
        if self.hidden_min_abs > 0:
            hy = torch.clamp(hy, min=self.hidden_min_abs)

        return hy

class IndRNN(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers=1, batch_first=True, bidirectional=False, nonlinearity='relu', hidden_min_abs=0):
        super().__init__()
        self.num_layers = num_layers
        self.batch_first = batch_first
        self.bidirectional = bidirectional
        self.hidden_size = hidden_size
        self.rnns = nn.ModuleList()
        for layer in range(num_layers):
            input_size_ = input_size if layer == 0 else hidden_size * 2 if bidirectional else hidden_size
            self.rnns.append(IndRNNCell(input_size_, hidden_size, nonlinearity, hidden_min_abs))

    def forward(self, input, h0=None):
        if self.batch_first:
            input = input.transpose(1, 0)

        if not h0:
            h0 = Variable(input.data.new(input.size(1), self.hidden_size).zero_())

        outs = []
        hn = []

        for l, rnn in enumerate(self.rnns):
            hy = h0[l]
            out = []
            for time in range(input.size(0)):
                hy = rnn(input[time], hy)
                out.append(hy)
            input = torch.stack(out)
            outs.append(input)
            hn.append(hy)

        if self.bidirectional:
            hn = torch.cat([hn[0], hn[-1]], dim=1)
            outs = [torch.cat([out[0], out[-1]], dim=2) for out in outs]

        if self.batch_first:
            outs = [out.transpose(1, 0) for out in outs]

        return outs, hn
class IndRNNModel(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, num_layers=1, bidirectional=False):
        super(IndRNNModel, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.bidirectional = bidirectional
        self.indrnn = nn.ModuleList()

        # 构建多层 IndRNN 网络
        for i in range(self.num_layers):
            input_dim = input_size if i == 0 else hidden_size * 2 if bidirectional else hidden_size
            output_dim = output_size if i == self.num_layers - 1 else hidden_size
            self.indrnn.append(IndRNN(input_dim, output_dim))

        # 线性层，将 IndRNN 模型的输出维度转化为预测目标的维度
        self.linear = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        # 输入数据形状：(batch_size, seq_len, input_size)
        batch_size, seq_len, input_size = x.size()
        outputs = []
        hn = []

        # 遍历多层 IndRNN 网络
        for i in range(self.num_layers):
            # 双向 IndRNN
            if self.bidirectional:
                h0_fw = None
                h0_bw = None
                x_fw = x
                x_bw = x.flip([1])

                output_fw, hn_fw = self.indrnn[i](x_fw, h0_fw)
                output_bw, hn_bw = self.indrnn[i](x_bw, h0_bw)

                hn_i = torch.cat([hn_fw, hn_bw], dim=1)
                output_i = torch.cat([output_fw, output_bw.flip([1])], dim=-1)

            # 单向 IndRNN
            else:
                h0 = None
                output_i, hn_i = self.indrnn[i](x, h0)

            # 保存当前层的输出和隐藏状态
            outputs.append(output_i)
            hn.append(hn_i)

            # 下一层的输入为当前层的输出
            x = output_i

        # 最后一层网络输出层
        output = self.linear(outputs[-1])

        return output


# 定义超参数
input_size = 5
hidden_size = 5
output_size = 5
num_epochs = 1
learning_rate = 0.0001

# 初始化模型
lstm_model =  IndRNN(input_size, hidden_size, output_size)

# 定义损失函数和优化器
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(lstm_model.parameters(), lr=learning_rate)
max_acc = 0

# 训练模型
for i in range(1000):
    for epoch in range(num_epochs):
        loss_sum = 0
        for train_x,train_y in zip(train_x_list,train_y_list):
            lstm_model.train()
            optimizer.zero_grad()
            outputs,_ = lstm_model(train_x)
            loss = criterion(outputs[-1].float(), train_y.float())
            loss.backward()
            optimizer.step()
            loss_sum += loss.item()
        if (epoch+1) % 10 == 0:
            print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {loss_sum:.4f}')

    # 测试模型
    lstm_model.eval()
    with torch.no_grad():
        total = 0
        correct = 0
        for val_x,val_y in zip(val_x_list,val_y_list):
            print(val_x)
            y_pred = lstm_model(val_x)
            test_loss = criterion(y_pred,val_y)
            # _, predicted = torch.max(y_pred.data, 1)
            predicted = torch.where(y_pred >= 0.5, 1, 0)
            total += predicted.size(0)*5
            correct += (predicted == val_y).sum().item()
        val_accuracy = correct / total
        # test_rmse = scaler.inverse_transform(np.sqrt(test_loss.item()))
        print(f'Test Accuracy: {val_accuracy:.4f},epoch {i}')
#         if max_acc < val_accuracy and i > 10:
#             max_acc = val_accuracy
#             torch.save(lstm_model.state_dict(), './checkpoint/ckpt' + name + '.t7')
# lstm_model.load_state_dict(torch.load('./checkpoint/ckptlstm.t7'))
# correct_l = 0
# total_l = 0
# with torch.no_grad():
#     for ii in range(10):
#         y_pred = lstm_model(X_test)
#         test_loss = criterion(y_pred, y_test)
#         _, predicted = torch.max(y_pred.data, 1)
#         total = predicted.size(0)
#         correct = (predicted == y_test).sum().item()
#         correct_l += correct
#         total_l += total
#     test_accuracy = correct_l / total_l
#
#         # test_loss = scaler.inverse_transform(np.sqrt(test_loss.item()))
#     print(f' Test Accuracy: {test_accuracy:.4f}')
