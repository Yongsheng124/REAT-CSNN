import torch
import torch.nn as nn
import torch.nn.functional as F
# 两种注意力机制的同时加入确实是可以大大提高时间序列的预测，可以稳定在68%
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("device", device)
thresh = 0.5  # neuronal threshold
lens = 0.5 / 3  # hyper-parameters of approximate function
decay = 0.8  # decay constants

# 调参是能够真正起到作用的
# 后面的记忆单元也找到原因了
# 还有就是差分了
# 这边的记忆单元是mem，通常来说这应该是模电流
decay1 = 0.9
num_classes = 2
batch_size = 20
learning_rate = 1e-4
num_epochs = 20  # max epoch


# define approximate firing function
class ActFun(torch.autograd.Function):
    @staticmethod
    def forward(ctx, input):
        ctx.save_for_backward(input)
        return input.gt(thresh).float()

    @staticmethod
    def backward(ctx, grad_output):
        input, = ctx.saved_tensors
        grad_input = grad_output.clone()
        # temp = abs(input - thresh) < lens
        temp = torch.exp(-(input - thresh) ** 2 / (2 * lens ** 2)) / ((2 * lens * 3.141592653589793) ** 0.5)
        return grad_input * temp.float()


act_fun = ActFun.apply


# def mem_update(ops, x,cur, mem, spike):
#     cur = ops(x)+cur*0.8
#     mem = mem * decay * (1. - spike) + cur
#     spike = act_fun(mem) # act_fun : approximation firing function
#     return cur , mem, spike
# membrane potential update
def mem_updateq(ops, ops1, x, mem, cur, spike):
    cur = cur * decay1 + ops(x) + ops1(spike)
    # print(cur.size())
    mem = mem * decay * (1. - spike) + cur
    spike = act_fun(mem)  # act_fun : approximation firing function
    return mem, cur, spike


def mem_update(ops, x, mem, cur, spike):
    cur = cur * decay1 + ops(x)
    # print(cur.size())
    mem = mem * decay * (1. - spike) + cur
    spike = act_fun(mem)  # act_fun : approximation firing function
    return mem, cur, spike


def mem_update1(ops, ops1, x, mem, cur, spike):
    # print(cur.size())
    # print(x.size())
    # cur_1 = torch.cat((cur,x),1)

    # cur_2 = ops(cur_1)
    cur_2 = ops1(cur) + ops(x)
    # print(cur.size())
    # print(x.size())
    mem = mem * decay * (1. - spike) + cur_2
    spike = act_fun(mem)  # act_fun : approximation firing function
    return mem, cur_2, spike


def mem_update2(ops, ops1, opsr, opss, x, mem, cur, spike):
    # print(cur.size())
    # print(x.size())
    # cur_1 = torch.cat((cur,x),1)

    # cur_2 = ops(cur_1)
    cur_2 = opss(ops(x))
    cur_3 = opsr(ops1(x))
    cur_4 = cur_2 * cur + (1 - cur_3) * cur_3
    # print(cur.size())
    # print(x.size())
    mem = mem * decay * (1. - spike) + cur_4
    spike = act_fun(mem)  # act_fun : approximation firing function
    return mem, cur_4, spike  # error


def mem_update3(ops, ops1, ops2, ops3, ops4, opss, opst, x, mem, cur, spike):
    # print(cur.size())
    # print(x.size())
    # cur_1 = torch.cat((cur,x),1)
    r = opss(ops(x) + ops1(cur))
    z = opss(ops2(x) + ops3(cur))
    hh = opst(ops4(x) + r * cur)
    cur_4 = z * cur + (1 - z) * hh
    # cur_2 = ops(cur_1)
    # cur_2 = opss(ops(x))
    # cur_3 = opsr(ops1(x))
    # cur_4 = cur_2*cur+(1-cur_3)*cur_3
    # print(cur.size())
    # print(x.size())
    mem = mem * decay * (1. - spike) + cur_4
    spike = act_fun(mem)  # act_fun : approximation firing function
    return mem, cur_4, spike


# cnn_layer(in_planes(channels), out_planes(channels), kernel_size, stride, padding)
cfg_cnn = [(12, 48, 3, 1, 1),
           (48, 48, 3, 1, 1),
           (48, 64, 3, 1, 1),
           (64, 64, 3, 1, 1), ]
# kernel size
# cnn output shapes (conv1, conv2, fc1 input)
cfg_kernel = [19, 18, 17, 8, 6]  # conv layers input image shape (+ last output shape)
# fc layer
cfg_fc = [32, 2]  # linear layers output


# Dacay learning_rate
def lr_scheduler(optimizer, epoch, init_lr=0.1, lr_decay_epoch=50):
    """Decay learning rate by a factor of 0.1 every lr_decay_epoch epochs."""
    if epoch % lr_decay_epoch == 0 and epoch > 1:
        for param_group in optimizer.param_groups:
            param_group['lr'] = param_group['lr'] * 0.1
    return optimizer


class ChannelAttention(nn.Module):
    def __init__(self, in_channels, reduction_ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.fc1 = nn.Conv2d(in_channels, in_channels // reduction_ratio, 1, bias=False)
        self.relu = nn.ReLU()
        self.fc2 = nn.Conv2d(in_channels // reduction_ratio, in_channels, 1, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc2(self.relu(self.fc1(self.avg_pool(x))))
        max_out = self.fc2(self.relu(self.fc1(self.max_pool(x))))
        out = avg_out + max_out
        return self.sigmoid(out)


class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()
        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1
        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv1(x)
        return self.sigmoid(x)


class SCNN(nn.Module):
    def __init__(self):
        super(SCNN, self).__init__()
        a1 = torch.zeros(128, 128)
        a2 = torch.zeros(2, 2)
        self.fuse_weight_1 = torch.nn.Parameter(torch.FloatTensor(a1), requires_grad=True)
        self.fuse_weight_2 = torch.nn.Parameter(torch.FloatTensor(a2), requires_grad=True)
        in_planes, out_planes, kernel_size, stride, padding = cfg_cnn[0]
        self.conv1 = nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=padding)

        self.ca1 = ChannelAttention(out_planes)
        self.sa1 = SpatialAttention()
        in_planes, out_planes, kernel_size, stride, padding = cfg_cnn[1]
        self.conv2 = nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=padding)
        self.ca2 = ChannelAttention(out_planes)
        self.sa2 = SpatialAttention()
        in_planes, out_planes, kernel_size, stride, padding = cfg_cnn[2]
        self.conv3 = nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=padding)
        self.ca3 = ChannelAttention(out_planes)
        self.sa3 = SpatialAttention()
        in_planes, out_planes, kernel_size, stride, padding = cfg_cnn[3]
        self.conv4 = nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride, padding=padding)

        self.fc1 = nn.Linear(12, 32)
        self.fc11 = nn.Linear(12, 32)
        self.fc111 = nn.Linear(12, 32)
        self.fc2 = nn.Linear(32,2)
        self.fc22 = nn.Linear(32, 2)
        self.fc222 = nn.Linear(32, 2)
        self.fc3 = nn.Linear(32, 32)  # 电流
        self.fc33 = nn.Linear(32, 32)
        # self.fc5 = nn.Linear(64,64)
        self.fc4 = nn.Linear(2, 2)
        self.fc44 = nn.Linear(2, 2)
        self.sigmoid = nn.Sigmoid()
        self.relu = nn.ReLU()
        self.tanh = nn.Tanh()

    def forward(self, input, time_window=9):
        # convolutional layers membrane potential and spike memory
        c1_cur = c1_mem = c1_spike = torch.zeros(batch_size * 2, cfg_cnn[0][1], cfg_kernel[0], cfg_kernel[0],
                                                 device=device)
        c2_cur = c2_mem = c2_spike = torch.zeros(batch_size * 2, cfg_cnn[1][1], cfg_kernel[1], cfg_kernel[1],
                                                 device=device)

        # linear layers membrane potential and spike memory
        c3_cur = c3_mem = c3_spike = torch.zeros(batch_size * 2, cfg_cnn[2][1], cfg_kernel[2], cfg_kernel[2],
                                                 device=device)
        c4_cur = c4_mem = c4_spike = torch.zeros(batch_size * 2, cfg_cnn[2][2], cfg_kernel[3], cfg_kernel[3],
                                                 device=device)

        h1_cur = h1_mem = h1_spike = h1_sumspike = torch.zeros(batch_size, cfg_fc[0], device=device)
        h2_cur = h2_mem = h2_spike = h2_sumspike = torch.zeros(batch_size, cfg_fc[1], device=device)
        # 做数据增强，batch_size的大小进行研究，序列数据方面，数据增强与batch_size
        # for 循环生成多组并行的数据
        for step in range(time_window):  # simulation time steps
            # 这是每一个激发的点,修改所有需要传递记忆的值
            # steps = 5 * step
            # print(input.shape)
            x = torch.squeeze(input[:, step: step + 1, :])
            # print(x)
            # c1_mem, c1_cur, c1_spike = mem_update(self.conv1, x.float(), c1_mem, c1_cur, c1_spike)
            # x = F.avg_pool2d(c1_spike, 2, stride=1, padding=0)
            # # print(x)
            # # x = c1_spike
            # x = self.ca1(x) * x
            # x = self.sa1(x) * x
            # c2_mem, c2_cur, c2_spike = mem_update(self.conv2, x, c2_mem, c2_cur, c2_spike)
            # x = F.avg_pool2d(c2_spike, 2, stride=1, padding=0)
            # # x = c2_spike
            # x = self.ca2(x) * x
            # x = self.sa2(x) * x
            # c3_mem, c3_cur, c3_spike = mem_update(self.conv3, x, c3_mem, c3_cur, c3_spike)
            # x = F.avg_pool2d(c3_spike, 2)
            # # x = c3_spike
            # x = self.ca3(x) * x
            # x = self.sa3(x) * x
            # x = x.view(batch_size * 2, -1)
            # # flatten
            h1_cur_1 = h1_cur.clone()
            # h1_spike_1 = h1_spike.clone()
            h1_mem,h1_cur, h1_spike = mem_update3(self.fc1, self.fc3,self.fc11,self.fc33,self.fc111,self.sigmoid,self.tanh,x, h1_mem, h1_cur_1, h1_spike)
            h1_sumspike += h1_spike
            h2_cur_2 = h2_cur.clone()
            # print(h2_cur_2)
            h2_mem,h2_cur, h2_spike = mem_update3(self.fc2, self.fc4,self.fc22,self.fc44,self.fc222,self.sigmoid,self.tanh,h1_spike, h2_mem, h2_cur_2, h2_spike)
            # h1_mem, h1_cur, h1_spike = mem_update2(self.fc1, self.fc11, self.sigmoid,
            #                                        self.tanh, x, h1_mem, h1_cur_1, h1_spike)
            # h1_sumspike += h1_spike
            # h2_cur_2 = h2_cur.clone()
            # h2_mem, h2_cur, h2_spike = mem_update2(self.fc2, self.fc22, self.sigmoid,
            #                                        self.tanh, h1_spike, h2_mem, h2_cur_2, h2_spike)
            # h1_mem, h1_cur, h1_spike = mem_update1(self.fc1, self.fc3, x, h1_mem, h1_cur_1, h1_spike_1)
            # h1_sumspike += h1_spike
            # h2_cur_2 = h2_cur.clone()
            # h2_spike_2 = h2_spike.clone()
            # h2_mem, h2_cur, h2_spike = mem_update1(self.fc2, self.fc4, h1_spike, h2_mem, h2_cur_2, h2_spike_2)

            # h1_mem,h1_cur, h1_spike = mem_update(self.fc1,x, h1_mem, h1_cur, h1_spike)
            # h1_sumspike += h1_spike
            # h2_cur_2 = h2_cur.clone()
            # # print(h2_cur_2)
            # h2_spike_2 = h2_spike.clone()
            # h2_mem,h2_cur, h2_spike = mem_update(self.fc2,h1_spike, h2_mem, h2_cur_2, h2_spike_2)
            h2_sumspike += h2_spike
        # outputs = h2_sumspike / time_window
        return h2_cur
