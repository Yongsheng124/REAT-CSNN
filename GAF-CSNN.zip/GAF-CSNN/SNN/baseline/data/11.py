import numpy as np
data = np.loadtxt('GAF-SNN.csv')
data = data/100
np.savetxt('GAF-SNN.csv',data,delimiter='\n')