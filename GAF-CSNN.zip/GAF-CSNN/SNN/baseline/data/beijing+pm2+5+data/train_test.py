import pandas as pd

# 读取原始csv文件
df = pd.read_csv("E:\py_code\conv_snn-master\Test_4\SNN\\baseline\data\\beijing+pm2+5+data\PRSA_data_2010.1.1-2014.12.31.csv")

# 分割前200条数据
first_200 = df[:30000]

# 分割后200条数据
last_200 = df[30000:40000]

# 将分割后的数据存储为新的csv文件
first_200.to_csv("train_pm.csv", index=False)
last_200.to_csv("test_pm.csv", index=False)
