from matplotlib import pyplot as plt
import pandas as pd
import os
import numpy as np
list_data = ['CNN1D.csv','GCN.csv','GRU.csv','LSTM.csv','SNN.csv','GAF-SNN.csv']
fig, ax = plt.subplots()
for i in range(len(list_data)):
    # fig, ax = plt.subplots()
    xx = [i for i in range(150)]
    print(xx)
    y = np.loadtxt(list_data[i])
    print(y)
    yy = list(y)
    print(yy)
    # 绘制折线图
    ax.plot(xx, yy,label=list_data[i])
    ax.legend(loc='best')
    # 设置 X 轴刻度的位置和标签
    # ax.set_xticks([0.4,0.5,0.6,0.7,0.8])
ax.set_yticks([0.45,0.5,0.6,0.7,0.75])
# ax.set_xticklabels([0.4,0.5,0.6,0.7,0.8])
ax.set_title('DATA')
    # 显示图形
plt.show()