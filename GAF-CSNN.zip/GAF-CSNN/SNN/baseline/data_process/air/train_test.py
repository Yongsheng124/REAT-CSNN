import numpy as np
data_x = np.load("data_air.npy")
data_y = np.load("label_air.npy")
# 8:2
train_len = int(data_x.shape[0]*0.8)
test_len = int(data_y.shape[0]*0.2)
train_x = data_x[0:train_len]
train_y = data_y[0:train_len]

test_x = data_x[train_len:]
test_y = data_y[train_len:]

np.save("train_air_x.npy",train_x)
np.save("train_air_y.npy",train_y)
np.save("test_air_x.npy",test_x)
np.save("test_air_y.npy",test_y)
