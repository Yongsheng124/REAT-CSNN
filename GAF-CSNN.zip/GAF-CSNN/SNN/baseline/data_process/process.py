import numpy as np
import pandas as pd

data = pd.read_csv('E:\py_code\conv_snn-master\Test_4\SNN\\baseline\data_process\pm\\train_pm.csv')
data_np = data[['pm2.5','DEWP','TEMP','PRES','Iws','Is','Ir']]

seg_length = 9
overlap = 8

total_len , num_dim = data_np.shape
start_indices = np.arange(0,total_len - seg_length + 1,seg_length-overlap)
end_indices = start_indices+seg_length
seg_data = []
seg_labels = []
for start , end in zip(start_indices[:-1],end_indices[:-1]):
    seg = data_np.iloc[start:end]
    last = seg.iloc[-1]
    next_value = data_np.iloc[end]
    seg_label = []
    for i in range(num_dim):
        if last[i] > next_value[i]:
            seg_label.append(0)
        else:
            seg_label.append(1)
    seg_labels.append(seg_label)
    seg_data.append(seg.values)
array_data = np.array(seg_data)
array_labels = np.array(seg_labels)
np.save("pm\\train_pm_x.npy",array_data)
np.save("pm\\train_pm_y.npy",array_labels)
