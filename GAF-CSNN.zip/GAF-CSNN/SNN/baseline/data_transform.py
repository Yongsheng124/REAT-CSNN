import numpy as np
import pandas as pd

data_1 = pd.read_csv('vua/act_bliz.csv')
data_2 = pd.read_csv('vua/nintendo.csv')
for i in range(data_2.shape[0]):
    if data_1['Date'][i] != data_2['Date'][i]:
        print(data_2['Date'][i])
# 定义文件名列表
filenames = ['vua/act_bliz.csv', 'vua/ea.csv', 'vua/nintendo.csv', 'vua/take_two.csv', 'vua/tencent.csv']

# 读取 CSV 文件并合并为一个 DataFrame 对象
data_list = []
for i in range(len(filenames)):
    data1 = pd.read_csv(filenames[i])

    data_list.append(data1['Close'])
data = pd.concat(data_list, axis=1)

# 转换为 Numpy 数组
data_array = np.array(data)
# data_array = data_array)[...,np.newaxis]
# 存储为 NPY 文件
np.save('data1.npy', data_array)
data2 = np.load('data1.npy')
print(data2)
print(data2.shape)