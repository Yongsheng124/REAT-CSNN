import os
import pandas as pd
import numpy as np

# 定义窗口大小和步长
window_size = 19
stride = 1

# 定义空列表存储所有样本和对应的标签
all_samples = []
all_labels = []

# 读取每个CSV文件并进行样本窗口分割
for file_name in os.listdir('E:\py_code\conv_snn-master\Test_4\SNN\\baseline\\vua_Train'):
    if file_name.endswith('.csv'):
        # 读取CSV文件
        data = pd.read_csv(os.path.join('E:\py_code\conv_snn-master\Test_4\SNN\\baseline\\vua_Train', file_name))

        # 对数据进行样本窗口分割，并计算每个样本的标签
        for i in range(0, len(data) - window_size, stride):
            sample = data.iloc[i:i + window_size, 1:-1]
            label = int(data.iloc[i + window_size, 4] > data.iloc[i + window_size-1, 4])
            all_samples.append(sample.values)
            all_labels.append(label)
all_samples = np.array(all_samples)
all_labels = np.array(all_labels)
print(1)
# 将所有样本和标签拼接起来
# all_data = np.concatenate((all_samples, np.array(all_labels).reshape(-1, 1)), axis=1)
#
# # 将拼接后的结果保存为新的CSV文件
# pd.DataFrame(all_data).to_csv('merged_samples_with_labels.csv', index=False)
