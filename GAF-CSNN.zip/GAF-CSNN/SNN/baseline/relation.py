import torch
data = torch.tensor([[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1],[1,1,1,1,1]])
torch.save(data, 'relation.pt')
data1 = torch.load('relation.pt')
print(data1)
print(data1.shape)