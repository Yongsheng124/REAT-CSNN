# import torch
# # output_size = 10
# # train_labels = torch.randint(0, output_size)
# # print(train_labels.shape)
# x = torch.tensor([1,1])
# output = torch.where(x > 0, torch.tensor(1), torch.tensor(0))
# print(output)
import torch

# import torch
#
# x = torch.randn(40, 2, 14,14)
# y = x.expand(40, 6, 14,14)
# print(y.shape)
# import torch
#
# # 创建一个(3,2,4)大小的三维张量
# x = torch.tensor([[[1, 2, 3, 4], [5, 6, 7, 8]],
#                   [[9, 10, 11, 12], [13, 14, 15, 16]],
#                   [[17, 18, 19, 20], [21, 22, 23, 24]]])
# print(x.shape)
#
# # 在第2维上进行扩展，每个元素按索引从0开始，重复i次
# expanded_x = x.repeat_interleave(torch.ones(x.shape[2],dtype=torch.int)*10, dim=2)
# print(torch.arange(x.shape[2]))
# print(expanded_x)
# print(expanded_x.shape)
# nums = [53.389, 53.111, 53.422, 53.700, 53.867, 52.778, 53.056, 54.011, 52.778, 53.956]
# avg = sum(nums)/len(nums)
# print(avg)
# gru = [0.5311, 0.5289, 0.5278, 0.5344, 0.5356, 0.5311, 0.5289, 0.5278, 0.5311, 0.5300]
# rnn = [0.5056, 0.5022, 0.5056, 0.5022, 0.5011, 0.4989, 0.5033, 0.5033, 0.5000, 0.5044]
# lstm = [0.5389, 0.5344, 0.5356, 0.5333, 0.5333, 0.5300, 0.5311, 0.5233, 0.5256, 0.5278]
# gcn = [0.5278, 0.5311, 0.5211, 0.5300, 0.5289, 0.5400, 0.5489, 0.5322, 0.5289, 0.5267]
# snn = [0.4856, 0.4844, 0.4867, 0.4878, 0.5033, 0.4900, 0.4889, 0.4889, 0.4867, 0.4856]
# gru_snn = [0.5233, 0.5256, 0.5244, 0.5233, 0.5267, 0.5200, 0.5222, 0.5244, 0.5167, 0.5133]
#
# avg_gru = sum(gru) / len(gru)
# avg_rnn = sum(rnn) / len(rnn)
# avg_lstm = sum(lstm) / len(lstm)
# avg_gcn = sum(gcn) / len(gcn)
# avg_snn = sum(snn) / len(snn)
# avg_gru_snn = sum(gru_snn) / len(gru_snn)
#
# print("Average GRU score:", avg_gru)
# print("Average RNN score:", avg_rnn)
# print("Average LSTM score:", avg_lstm)
# print("Average GCN score:", avg_gcn)
# print("Average SNN score:", avg_snn)
# print("Average GRU_SNN score:", avg_gru_snn)
# 最大池化
max_pool = [[53.000, 52.722, 52.833, 52.667, 52.833, 52.167, 53.278, 53.000, 53.333, 53.667],
            [53.222, 52.611, 53.333, 52.944, 52.889, 52.722, 52.500, 53.000, 53.333, 53.333],
            [52.500, 52.556, 52.611, 52.944, 52.167, 52.556, 52.556, 52.667, 52.611, 52.500],
            [53.389, 52.333, 53.111, 52.722, 52.833, 53.556, 52.500, 52.778, 52.333, 53.056],
            [52.500, 52.556, 52.389, 53.222, 52.389, 52.778, 52.167, 52.278, 53.000, 53.389]]
max_pool_avg_list = [sum(row) / len(row) for row in max_pool]
print("最大池化平均值：", max_pool_avg_list)

# 最多池化
avg_pool = [[52.989, 52.433, 52.278, 52.356, 52.667, 52.767, 53.467, 52.644, 52.578, 53.600],
            [52.889, 53.278, 54.389, 54.111, 54.778, 52.667, 54.444, 53.778, 54.167, 53.000],
            [53.033, 52.722, 53.033, 53.044, 53.233, 53.622, 53.578, 53.811, 53.489, 53.989],
            [53.389, 53.111, 53.422, 53.700, 53.867, 52.778, 53.056, 54.011, 52.778, 53.956],
            [53.522, 53.489, 53.389, 52.856, 54.178, 54.500, 52.711, 53.544, 54.100, 53.867]]
avg_pool_avg_list = [sum(row) / len(row) for row in avg_pool]
print("最多池化平均值：", avg_pool_avg_list)
