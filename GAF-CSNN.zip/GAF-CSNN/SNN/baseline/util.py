
import torch

import numpy as np
import os

from scipy.stats import pearsonr

os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'


def pad_with_last_val(vect,k):
    device ='cpu'
    pad = torch.ones(k - vect.size(0),
                         dtype=torch.long,
                         device = device) * vect[-1]
    vect = torch.cat([vect,pad])
    return vect

def load_daily(data_path):  #数据已经处理过
    print('---------------加载数据---------------')
    data=np.load(data_path)
    data=torch.from_numpy(data)
    print(data.shape)

    prelabel = data[:,:, 0]
    postlabel=torch.zeros_like(prelabel)
    # 数据预处理
    max, _ = torch.max(data, dim=1)
    max = torch.unsqueeze(max, 1)
    min, _ = torch.min(data, dim=1)
    min = torch.unsqueeze(min, 1)

    data=(data - min) / (max - min)

    # 处理label
    for i,_ in enumerate(prelabel):         #计算涨跌幅度
        for j in range(1,_.shape[0]):
            postlabel[i,j]=(prelabel[i,j]-prelabel[i,j-1])/prelabel[i,j-1]
    postlabel[:,0]=0
    # 第一个维度应该就是股票的数量
    train_data=data[:,:1920]
    train_label=postlabel[:,:1920]
    test_data=data[:,1970:2890]
    test_label=postlabel[:,1970:2890]

    print('训练集数据:',train_data.shape)
    print('训练集标签:',train_label.shape)
    print('测试集数据:',test_data.shape)
    print('测试集标签:',test_label.shape)
    print('---------------加载完成---------------')
    return train_data,train_label,test_data,test_label

def load_manhadun(data_path):  #数据已经处理过
    print('---------------加载数据---------------')
    data=np.load(data_path)
    data=torch.from_numpy(data)

    prelabel = data[:,:, 1]
    postlabel=torch.zeros_like(prelabel)
    #数据预处理
    max, _ = torch.max(data, dim=1)
    max = torch.unsqueeze(max, 1)
    min, _ = torch.min(data, dim=1)
    min = torch.unsqueeze(min, 1)

    data=(data - min) / (max - min)

    # 处理label
    for i,_ in enumerate(prelabel):         #计算涨跌幅度
        for j in range(1,_.shape[0]):
            postlabel[i,j]=(prelabel[i,j]-prelabel[i,j-1])/prelabel[i,j-1]
    postlabel[:,0]=0

    return data,postlabel

# def load_THS_adj2(relation_path):
#     A=torch.load(relation_path).numpy()
#     #A=np.load(relation_path)
#     for i in range(A.shape[0]):
#         A[i]=normalize(A[i])
#     A=torch.from_numpy(A)
#     return A

def load_THS_adj_batch(rela_path):
    A=torch.load(rela_path).numpy()
    for i in range(len(A)):
        A[i]=normalize(A[i])
    A = torch.from_numpy(A)
    return A

def load_THS_adj2(relation_path):
    A=torch.load(relation_path)
    return A

def load_THS_adj3(relation_path):
    A=torch.load(relation_path).numpy()
    for i in range(600):
        for j in range(600):
            if A[i,j]==1:
                A[j,i]=1
    #A=np.load(relation_path)
    A=normalize(A)
    A=torch.from_numpy(A)
    return A


def normalize(mx):
    rowsum = np.array(mx.sum(1))
    r_inv = np.power(rowsum, -(1/2)).flatten()
    r_inv[np.isinf(r_inv)] = 0.

    r_mat_inv = np.diag(r_inv)
    mx = r_mat_inv.dot(mx)
    mx = mx.dot(r_mat_inv)
    return mx

def load_close(close_path):
    data=np.load(close_path)
    label=torch.from_numpy(data)

    train_close=label[:,:600]
    test_close=label[:,580:]
    return train_close,test_close

def load_THS_adj(relation_path):
    #A=torch.load(relation_path).numpy()
    A=np.load(relation_path)
    A=normalize(A)
    A=torch.from_numpy(A)
    return A



def norm(x):
    return (x-torch.min(x))/(torch.max(x)-torch.min(x))

def norm2(a):
    return (a - torch.min(a, dim=1)[0].unsqueeze(1)) / (
                torch.max(a, dim=1)[0].unsqueeze(1) - torch.min(a, dim=1)[0].unsqueeze(1))

def make_similar_adj(data,day):  #day之前10天的数据  data是600*600
    A=torch.DoubleTensor(data.shape[0],data.shape[0])

    for i in range(600):
        for j in range(600):
            A[i][j]=pearsonr(norm(data[i][day-10:day]),norm(data[j][day-10:day]))[0]
            #print(norm(data[i][day-10:day]),'\n',norm(data[j][day-10:day]))
            #A[i][j]=F.kl_div(F.log_softmax(norm(data[i][day-10:day]), dim=-1), F.softmax(norm(data[j][day-10:day]), dim=-1), reduction='batchmean')

    B=torch.where(A>=.9,A,0.9)
    B=(B-0.9)*10
    return B

if __name__=='__main__':
    path='close_data.npy'
    train_close,test_close=load_close(path)
    print(train_close.shape)
    print(test_close.shape)
    torchtrain=torch.zeros(590,600,600)
    torchtest=torch.zeros(160,600,600)
    for i in range(len(train_close)-10):
        print('train',i)
        A=make_similar_adj(train_close,i+10)
        print(A[:10:10])
        #A=normalize(A.numpy())
        #A=torch.from_numpy(A)
        torchtrain[i]=A
    torch.save(torchtrain,'lisA_train.torch')

    for i in range(160):
        print('test',i)
        A=make_similar_adj(test_close,i+10)
        #A=normalize(A.numpy())
        #A=torch.from_numpy(A)
        torchtest[i]=A
    torch.save(torchtest,'lisA_test.torch')

