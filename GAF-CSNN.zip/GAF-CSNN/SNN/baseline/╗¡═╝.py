import numpy as np
import matplotlib.pyplot as plt

# 随机生成一个5行10列的矩阵，其中每个元素的值为0或1
matrix = np.random.randint(low=0, high=2, size=(19, 19))

# 可视化矩阵
plt.imshow(matrix, cmap='binary')
plt.xticks([])
plt.yticks([])
plt.show()
