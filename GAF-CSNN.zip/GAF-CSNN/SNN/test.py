import torch
import matplotlib.pyplot as plt
file_name = 'data.pt'
# 没有进行池化
loaded_data_list = torch.load(file_name)
file_name1 = 'data1.pt'
# 最大池化
loaded_data_list1 = torch.load(file_name1)
file_name2 = 'data2.pt'
loaded_data_list2 = torch.load(file_name2)
# 使用 for 循环遍历列表对象，依次输出其中的每个 Tensor 对象
# for data in loaded_data_list:
#     print(data[0,3,:,:])
#     img_tensor = data[0,3,:,:]
#     img_np = img_tensor.cpu().numpy()
#
#     # 使用Matplotlib的imshow函数展示图像，将范围设置为[0, 1]，viridis颜色映射，并去掉坐标轴显示
#     plt.imshow(img_np, vmin=0, vmax=1, cmap='viridis')
#     plt.xticks([])
#     plt.yticks([])
#     plt.axis('off')
#     plt.show()
# 将其进行作图
# for data1 in loaded_data_list1:
#     print(data1[0,3,:,:])
#     img_tensor = data1[0, 3, :, :]
#     # print(img_tensor)
#     img_np = img_tensor.cpu().numpy()
#
#     # 使用Matplotlib的imshow函数展示图像，将范围设置为[0, 1]，viridis颜色映射，并去掉坐标轴显示
#     plt.imshow(img_np, cmap='viridis', vmin=0, vmax=1)
#     plt.xticks([])
#     plt.yticks([])
#     plt.axis('off')
#     plt.show()
# # 这个是脉冲池化
for data2 in loaded_data_list2:
    print(data2[0, 3, :, :])
    img_tensor = data2[0, 3, :, :]
    # tensor_numpy = img_tensor.cpu().numpy()
    img_np = img_tensor.cpu().numpy()

    # 使用Matplotlib的imshow函数展示图像，将范围设置为[0, 1]，viridis颜色映射，并去掉坐标轴显示
    plt.imshow(img_np, cmap='viridis', vmin=0, vmax=1)
    plt.xticks([])
    plt.yticks([])
    plt.axis('off')
    plt.show()
    # 使用Matplotlib的imshow函数展示图像
    # plt.imshow(tensor_numpy)
    # plt.show()