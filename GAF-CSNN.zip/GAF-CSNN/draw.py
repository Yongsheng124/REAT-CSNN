import matplotlib.pyplot as plt
import numpy as np
import math


def log_function(array):
    for i in range(len(array)):
        array[i] = math.log(array[i])


models = ['RNN', 'LSTM', 'GRU', 'GCN', 'LSNN', 'REAT-CSNN']
flop_energy = [89984, 179948, 224960, 126624, 5377, 84714.3]
float32_energy = [206963.2, 413926.4, 517408, 291235.2, 4839.3, 381214.35]
int32_energy = [143974.4, 287948.8, 359936, 201667.2, 537.7, 84714.3]
log_function(flop_energy)
log_function(float32_energy)
log_function(int32_energy)

x = np.arange(len(models)) * 2
print(x)
width = 0.38

flop_x = x
float32_x = x + width
int32_x = x + 2 * width

plt.bar(flop_x, flop_energy, width=width, color="#8ecfc9", label='FLOP', alpha=0.6)
plt.bar(float32_x, float32_energy, width=width, color="#FA7F6F", label='Float32', alpha=0.6)
plt.bar(int32_x, int32_energy, width=width, color="#9394e7", label='Int32', alpha=0.6)
plt.xticks(x + width, labels=models, fontsize=12)
plt.yticks(fontsize=14)
# 去掉上边框和右边框
plt.gca().spines['top'].set_visible(False)
plt.gca().spines['right'].set_visible(False)
plt.axhline(11.30, color='#FA7F6F', linestyle='dashed')
plt.axhline(12.83, color='#82B0D2', linestyle='dashed')

# 添加背景高亮

plt.axvspan(7.5, 11.2, facecolor='yellow', alpha=0.15)  # 水平高亮

# 添加说明
# plt.text(-0.4, 15, 'lg(Energy)', ha='center')
plt.xlabel('Model', fontsize=14)
plt.ylabel('lg(Energy consumption)', fontsize=14)
# 设置网格
plt.grid(True, alpha=0.3, linewidth=0.5)

flop_energy2 = [89984, 179948, 224960, 126624, 5377, 84714]
float32_energy2 = [206963, 413926, 517408, 291235, 4839, 381214]
int32_energy2 = [143974, 287948, 359936, 201667, 537, 84714]

# for i in range(len(models)):
#     plt.text(flop_x[i], flop_energy[i], flop_energy2[i], va="bottom", ha="center", fontsize=10, rotation='60')
#     plt.text(float32_x[i]+0.3, float32_energy[i], float32_energy2[i], va="bottom", ha="center", fontsize=10,
#              rotation='60')
#     plt.text(int32_x[i]+0.2, int32_energy[i], int32_energy2[i], va="bottom", ha="center", fontsize=10, rotation='60')
plt.legend(bbox_to_anchor=(0.32, 1.1), ncol=3,loc='upper center')

plt.show()

# x = np.arange(10)
# y = 2 ** x + 10
# plt.bar(x, y, facecolor='#9999ff', edgecolor='white')
# for x, y in zip(x, y):
#     plt.text(x, y + 0.4, '%.2f' % y, ha='center', va='bottom')
# plt.show()
