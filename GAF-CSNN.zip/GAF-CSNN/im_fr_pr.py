import timeseries_to_gaf as ttg
from pandas.tseries.holiday import USFederalHolidayCalendar as Calendar
from multiprocessing import Pool
import pandas as pd
import os
import datetime as dt
from typing import *
import numpy as np
# df是一个变量
import csv
import os

PATH = os.path.dirname(__file__)
IMAGES_PATH = os.path.join(PATH, 'GAA/600197')
TEST_PATH = os.path.join(PATH, 'GAA/600197')
DATA_PATH = os.path.join(PATH, 'vua_Test')

# 首先将别的数据按照相同的处理
# 最终打标签的时候都是使用目标股票的标签来进行存储多重写几个函数同时对储存好的desion进行生成图像
data_list1 = os.listdir('E:\\Learning-python\\GAF-CSNN\\vua_Train')
data_list2 = os.listdir('E:\\Learning-python\\GAF-CSNN\\vua_Test')


def data_to_image_preprocess() -> None:
    """
    :return: None
    """
    for ss in data_list2:
        print('PROCESSING DATA')
        ive_data = ss
        ive_data1 = 'act_bliz_test.csv'
        print(ive_data1 == ive_data)
        df = pd.read_csv(os.path.join(DATA_PATH, ive_data))
        # Drop unnecessary data_slice
        df = df.drop(['Open', 'High', 'Low', 'Volume', 'Currency'], axis=1)
        df['DateTime'] = pd.to_datetime(df['Date'], infer_datetime_format=True)
        df = df.groupby(pd.Grouper(key='DateTime', freq='1d')).mean().reset_index()  # '1min'
        df['Close'] = df['Close'].replace(to_replace=0, method='ffill')
        clean_df = clean_non_trading_times(df)
        print(clean_df)
        df1 = pd.read_csv(os.path.join(DATA_PATH, ive_data1))
        # Drop unnecessary data_slice
        df1 = df1.drop(['Open', 'High', 'Low', 'Volume', 'Currency'], axis=1)
        df1['DateTime'] = pd.to_datetime(df1['Date'], infer_datetime_format=True)
        df1 = df1.groupby(pd.Grouper(key='DateTime', freq='1d')).mean().reset_index()  # '1min'
        df1['Close'] = df1['Close'].replace(to_replace=0, method='ffill')
        # Remove non trading days and times
        clean_df = clean_non_trading_times(df)
        clean_df1 = clean_non_trading_times(df1)
        print(clean_df == clean_df1)
        set_gaf_data(clean_df, clean_df1, ss)


def clean_non_trading_times(df: pd.DataFrame) -> pd.DataFrame:
    """
    :param df: Data with weekends and holidays
    :return trading_data:
    """
    # Weekends go out
    df = df[df['DateTime'].dt.weekday < 5].reset_index(drop=True)
    df = df.set_index('DateTime')
    # Remove non trading hours
    # df = df.between_time('9:00', '16:00')
    df.reset_index(inplace=True)
    # Holiday days we want to delete from data_slice
    holidays = Calendar().holidays(start='2000-01-01', end='2022-12-31')
    m = df['DateTime'].isin(holidays)
    clean_df = df[~m].copy()
    trading_data = clean_df.fillna(method='ffill')
    return trading_data


def set_gaf_data(df: pd.DataFrame, df1: pd.DataFrame, ss) -> None:
    """
    :param df: DataFrame data_slice
    :return: None
    """
    dates = df['DateTime'].dt.date
    # 获取日期数据
    # 这个地方是按天来的
    dates = dates.drop_duplicates()
    # 这句话没用，date里面怎么会有重复值呢

    list_dates = dates.apply(str).tolist()
    # 转换数据格式成list的格式，每个元素都是日期
    print(len(list_dates))

    # debug确实是一种学习的手段，通过这种手段可以看到数据的流动。
    index = 10
    # Container to store data_slice for the creation of GAF
    decision_map = {key: [] for key in ['LONG', 'SHORT']}
    # decision_map = {'LONG': [], 'SHORT': []}
    decision_map1 = {key: [] for key in ['LONG', 'SHORT']}
    while True:
        if index >= len(list_dates) - 1:
            break
        # Select appropriate timeframe
        data_slice = df.loc[(df['DateTime'] > list_dates[index - 10]) & (df['DateTime'] < list_dates[index])]
        data_slice1 = df1.loc[(df['DateTime'] > list_dates[index - 10]) & (df['DateTime'] < list_dates[index])]
        gafs = []
        gafs1 = []
        # Group data_slice by time frequency
        # for freq in ['1h', '2h', '4h', '1d']:
        freq = '1d'
        group_dt = data_slice.groupby(pd.Grouper(key='DateTime', freq=freq)).mean().reset_index()
        group_dt1 = data_slice1.groupby(pd.Grouper(key='DateTime', freq=freq)).mean().reset_index()
        # 把一个时间周期中的全部计算平均值
        group_dt = group_dt.dropna()
        group_dt1 = group_dt1.dropna()
        gafs.append(list(group_dt['Close'].tail(10)))
        gafs1.append(list(group_dt1['Close'].tail(10)))
        # Decide what trading position we should take on that day
        future_value = df[df['DateTime'].dt.date.astype(str) == list_dates[index]]['Close'].iloc[-1]
        current_value = data_slice['Close'].iloc[-1]
        decision = trading_action(future_close=future_value, current_close=current_value)
        decision_map[decision].append(tuple([list_dates[index - 1], gafs[0], 0 if decision == 'LONG' else 1]))
        index += 1
    # print(decision_map)
    # SHORT是1
    # LONG是0
    data_1 = decision_map['SHORT']
    data_2 = decision_map['LONG']
    merged_list = data_1 + data_2
    sorted_list = sorted(merged_list, key=lambda x: x[0])


    # 假设有一个列表data，其中包含多个数据类型的元素
    data_list = []
    for i in range(len(sorted_list)):
        data_list.append(sorted_list[i])
    # 将数据转换为NumPy数组
    array_data = np.array(data_list)

    # 定义.npy文件路径
    npy_file = 'test_series\\sort_' + ss[:-4] + '.npy'
    print(npy_file)
    # 将数据写入.npy文件
    np.save(npy_file, array_data)
    print("Numpy数组写入.npy文件完成.")

def trading_action(future_close: int, current_close: int) -> str:
    """
    :param future_close: Integer
    :param current_close: Integer
    :return: Folder destination as String
    """
    current_close = current_close
    future_close = future_close
    if current_close < future_close:
        decision = 'LONG'
    else:
        decision = 'SHORT'
    return decision


def generate_gaf(images_data: Dict[str, pd.DataFrame], name: str) -> None:
    """
    :param name:
    :param images_data:
    :return:
    """
    for decision, data in images_data.items():
        for image_data in data:
            to_plot = [ttg.create_gaf(x)['gadf'] for x in image_data[1]]
            ttg.create_images(X_plots=to_plot,
                              image_name='{0}'.format(image_data[0].replace('-', '')),
                              destination=decision,
                              prename='M_test\\',
                              name=name)


if __name__ == "__main__":
    pool = Pool(os.cpu_count())
    print(dt.datetime.now())
    print('CONVERTING TIME-SERIES TO IMAGES')
    pool.apply(data_to_image_preprocess)
    print('DONE!')
    print(dt.datetime.now())
