# 有一个初级的思路就是先将不同文件的数据统一到csv文件中
# 环境：macosx、stackless python & twisted
import os

import numpy as np
import pandas as pd
import datetime
cmd = 'E:\pycharmproject\pythonA\\600519.SH'  # 全路径或者./相对路径
import subprocess

# p = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
# while p.poll() == None:
#     line = p.stdout.readline()
#     print(line)  # 必须执行print，否则一直不返回，原因不明
#     # result = result + line
# p = np.loadtxt("E:\py_code\FinancialForecastingCNN-main\ShangA\\600197.SH")
# np.savetxt("AA\\600197.csv", p, delimiter=",")
# p1 = np.loadtxt("E:\py_code\FinancialForecastingCNN-main\ShangA\\600519.SH")
# np.savetxt("AA\\600519.csv", p1, delimiter=",")
# p2 = np.loadtxt("E:\py_code\FinancialForecastingCNN-main\ShangA\\600771.SH")
# np.savetxt("AA\\600771.csv", p2, delimiter=",")
# p3 = np.loadtxt("E:\py_code\FinancialForecastingCNN-main\ShangA\\600809.SH")
# np.savetxt("AA\\600809.csv", p3, delimiter=",")
# p4 = np.loadtxt("E:\py_code\FinancialForecastingCNN-main\ShangA\\603198.SH")
# np.savetxt("AA\\603198.csv", p4, delimiter=",")
# p5 = np.loadtxt("E:\py_code\FinancialForecastingCNN-main\ShangA\\603589.SH")
# np.savetxt("AA\\603589.csv", p5, delimiter=",")
# p1 = pd.read_csv("E:\py_code\FinancialForecastingCNN-main\TimeSeries\\tencent.csv")
# print(p1)
# p = np.loadtxt("E:\py_code\FinancialForecastingCNN-main\BSeries\\000568.SZ.csv")
path = r'E:\py_code\FinancialForecastingCNN-main\BBseries'

items = os.listdir(path)
min_l = 50000
def string_to_date(string: str) -> str:
    """字符串转日期格式"""
    from datetime import datetime
    shift_datetime = datetime.strptime(string, '%Y%m%d')  # 字符串 -> 时间
    shift_date = shift_datetime.strftime("%Y-%m-%d")  # 时间 -> 任意时间格式
    return shift_date

def convert_date_from_int(time_series: pd.Series):
    """整形的series -> pandas时间格式"""
    time_series = time_series.astype('str').apply(string_to_date)
    return pd.to_datetime(time_series)
ss = []
sss = []
for i in range(len(items)):
    p = pd.read_csv("E:\py_code\FinancialForecastingCNN-main\BBseries\\"+items[i])
    # 可以直接在文件后面加上后缀之后对文件进行python常用包对产用类型的文件进行读取
    # iloc函数是需要使用位置下标进行索引
    # 将数据倒序写入到文件中
    p1 = p[['trade_date','open','high','low','close','pre_close']]
    p1.columns = ['Date','Open','High','Low','Close','Volume']
    print(p)
    print(p1)
    p1['Date'] = convert_date_from_int(p1['Date'])
    # 根据其中一列中是否有将所有
    p1 = p1.dropna(axis=0, subset=['Close'])
    aa = []
    aa.append(items[i])
    aa.append(len(p1))
    sss.append(aa)
    ss.append(len(p1))
    if min_l > len(p1):
        min_l = len(p1)
print(min_l)
print(ss)
print(items)
print(sss)
# 568\596\799\858\860\930\600197\600199\600238\600257\600300\600382\600395\600519\600655\600696\600702\600750\
# 600771\600779\600809\
# 根据ss数组的信息对股票的种类型进行选取
for i in range(len(items)):
    p = pd.read_csv("E:\py_code\FinancialForecastingCNN-main\BBseries\\"+items[i])
    # 可以直接在文件后面加上后缀之后对文件进行python常用包对产用类型的文件进行读取
    # iloc函数是需要使用位置下标进行索引
    p1 = p[['trade_date','open','high','low','close','pre_close']]
    p1.columns = ['Date','Open','High','Low','Close','Volume']
    print(p)
    print(p1)
    p1['Date'] = convert_date_from_int(p1['Date'])
    # 根据其中一列中是否有将所有
    p1 = p1.dropna(axis=0,subset=['Close'])
    # 是有wrong的loc
    # 计算每一个长度
    p2 = p1[0:min_l]
    p3 = p2[::-1]
    dd = items[i].split('.')
    p3.to_csv('AAseries\\'+dd[0]+'.'+dd[2],index=None)

# 以下代码说明，两个##是不会用到的，其中一个#是有用的
# 整个思路：
# 将文件夹中的文件进行遍历读取所有的文件，并将其存在一个列表中

# # setTime = '2020-08-01'
# # now=datetime.datetime.strptime(setTime,'%Y-%m-%d')
# # endnow = now + datetime.timedelta(days=789)
# # print(endnow)
# # 这边同样是进行
# a = np.arange('2020-08-01', '2022-09-29', dtype=np.datetime64)
# # 文件ASeries是用来对处理好之后数据
# # 先尝试一下不好的数据是否能够与读取成功
# b = pd.DataFrame(p)
#
# b.columns = ['Open','Close','High','Low','Volume']
# b.insert(loc = 0,column = 'Date',value = a)
# print(b)
# # 这边新的数据是有column的所以不需要另外加，只需要选取1:6列就可以了
# b.to_csv("AA\\603589.csv",index=None)
# p1 = np.loadtxt("E:\py_code\FinancialForecastingCNN-main\ShenA\\000596.SZ")
# np.savetxt("BB\\000596.csv", p1, delimiter=",")
# p2 = np.loadtxt("E:\py_code\FinancialForecastingCNN-main\ShenA\\000799.SZ")
# np.savetxt("BB\\000799.csv", p2, delimiter=",")
# p3 = np.loadtxt("E:\py_code\FinancialForecastingCNN-main\ShenA\\000858.SZ")
# np.savetxt("BB\\000858.csv", p3, delimiter=",")
# p4 = np.loadtxt("E:\py_code\FinancialForecastingCNN-main\ShenA\\000860.SZ")
# np.savetxt("BB\\000860.csv", p4, delimiter=",")
# p5 = np.loadtxt("E:\py_code\FinancialForecastingCNN-main\ShenA\\002304.SZ")
# np.savetxt("BB\\002304.csv", p5, delimiter=",")



