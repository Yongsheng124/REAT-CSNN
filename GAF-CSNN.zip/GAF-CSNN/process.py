# 读取每一个文件中的close
import os
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from sklearn import preprocessing

path = r'E:\py_code\FinancialForecastingCNN-main\vua_Train'
item = os.listdir(path)
a = []

for i in range(len(item)):
    p = pd.read_csv('E:\py_code\FinancialForecastingCNN-main\\vua_Train\\'+item[i])
    # 读取每一个文件对每一列求解
    # 也可以处理成以某一个基准日期进行插补
    p = np.array(p)
    print(p)
    p3 = [[0 for kk in range(p.shape[1] - 1)] for kk in range(p.shape[0])]
    print(p.shape[1]-1)
    p4 = np.array(p3)
    p4.dtype = 'float32'
    for j in range(1,p.shape[0]):
        for k in range(1,p.shape[1]-1):
            p4[j][k] = p[j][k] - p[j-1][k]
    p[1:,1:-1] = p4[1:,1:]
    print(p4)
    p1 = p[1:]

    p2 = pd.DataFrame(p1)
    p2.columns = ['Date','Open','High','Low','Close','Volume','Currency']
    print(p2)
    p2.to_csv("vue_Train1\\"+item[i],index=None)






