import os

# Creates directories and sub directories needed for the project to run
print('Creating Directories:')
PATH = os.path.dirname(__file__)
GAF = os.path.join(PATH, 'M_train2')
print("GAF", GAF)
item = os.listdir("vua_Train")
# 得到vua_train下的四个数据集


# 写算法程序来解决问题可以非常的高效率
for i in range(len(item)):
    TRAIN_PATH = os.path.join(GAF, item[i].split('.')[0])
    TRAIN_LONG = os.path.join(TRAIN_PATH, 'LONG')
    TRAIN_SHORT = os.path.join(TRAIN_PATH, 'SHORT')
    os.makedirs(TRAIN_LONG)
    os.makedirs(TRAIN_SHORT)
    print("TRAIN_PATH", TRAIN_PATH)
    print("TRAIN_LONG", TRAIN_LONG)
    print("TRAIN_SHORT", TRAIN_SHORT)
    # print(DATA_PATH)
    # print(MODELS_PATH)
# 对五个游戏公司的训练集都生成TRAIN_PATH E:/Learning-python/GAF-CSNN\M_train2\tencent_train
# TRAIN_LONG E:/Learning-python/GAF-CSNN\M_train2\tencent_train\LONG
# TRAIN_SHORT E:/Learning-python/GAF-CSNN\M_train2\tencent_train\SHORT
# 这样的目录。最后生成目录

# M_Train2下有五个公司，每个公司下有LONG和SHORT两个包