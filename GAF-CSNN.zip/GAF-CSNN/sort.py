import os
import re
import numpy as np
# lst = ['pic-1-3', 'pic-3-3', 'pic-2-4', 'pic-1-0', 'pic-6-1']
# lst.sort()  # 当字符串中的数字不止一位时无法简单利用key进行索引
# print(lst)
# # 你会发现 result = ['pic-13', 'pic-104', 'pic-2', 'pic-3', 'pic-6'] 不合自己要求，这个和字符串的排序机制有关，暂不分析
# lst.sort(key=lambda l: int(re.findall('\d+', l)[1]))  # 找出字符串中的数字并依据其整形进行排序
# print(lst)
# 对字符串中的第几个数字进行更新
# result = ['pic-1', 'pic-2', 'pic-3', 'pic-6', 'pic-10']  # 符合预期按顺序排序
# Open file
data_train_1 = []
label_train_1 = []
data1_head = ['sort_act_bliz_test.npy','sort_ea_test.npy','sort_nintendo_test.npy','sort_take_two_test.npy','sort_tencent_test.npy']
for i in data1_head:
    array_2 = np.load("test_series/"+i,allow_pickle=True)
    data_2 = []
    label_2 = []
    for j in range(array_2.shape[0]):
        data_2.append(array_2[j][1])
        label_2.append(array_2[j][2])
    data_train_1.append(data_2)
    label_train_1.append(label_2)
train_data = np.transpose(np.array(data_train_1),(1,2,0))
train_label = np.transpose(np.array(label_train_1))
data_test_1 = []
label_test_1 = []
data_head = ['sort_act_bliz_test.npy','sort_ea_test.npy','sort_nintendo_test.npy','sort_take_two_test.npy','sort_tencent_test.npy']
for i in data_head:
    array_1 = np.load("test_series/"+i,allow_pickle=True)
    data_1 = []
    label_1 = []
    for j in range(array_1.shape[0]):
        data_1.append(array_1[j][1])
        label_1.append(array_1[j][2])
    data_test_1.append(data_1)
    label_test_1.append(label_1)
test_data = np.transpose(np.array(data_test_1),(1,2,0))
test_label = np.transpose(np.array(label_test_1))

path = r'E:\Learning-python\GAF-CSNN\SNN\M_cls_M_train1'
path1 = r'E:\Learning-python\GAF-CSNN\SNN\M_cls_M_train1'

item = os.listdir(path)
for i in range(len(item)):
    fileHandler = open(path+'\\'+item[i],  "r")
    # Get list of all lines in file
    listOfLines = fileHandler.readlines()
    # Close file
    # 先遍历所有的字符串把“_”全部进行替换
    # for i in range(len(listOfLines)):
    #     listOfLines[i] = listOfLines[i].replace('_','',3)
    listOfLines.sort(key=lambda l: int(re.findall('\d+', l)[2]))

    print(listOfLines)
    fileHandler.close()
    # 该函数是会直接对路径上的文件进行创建
    with open(path1+'\\'+item[i], 'w') as f:
        for j,s in enumerate(listOfLines):
            # s = str(train_label[j][i])+s[1:]
            f.write(s)

# 修改方案：
# 1.只需要对一个进行排序就足够了
# 2.所有的都要进行排序，但是顺序是一样的
# 3.把所有的进行排序之后
# 4.分步实现现在穿件副本文件来实现单个股票的变化的（10,10）
# 5.另一种方案是实现股票步长依旧是（20,5）只是关注变化的是5
# 6.最后建立一个对比实验：只使用一个信息
# 7.最开始的main可以直接将数据进行打乱里训练是不是更好地，这是分成了多个样本来进行训练
# 8.后面可能涉及到修改标签或者网络结构
# 9.需要一直对数据的格式进行调整知道出现高的精确度
# 10.缺少的两个实验:
# 只是使用一个图像的SNN
# 综合大实验（关系加动态）
# 对图像创新的实验（只使用一个图像就足够了）
# 股票模式进行分类