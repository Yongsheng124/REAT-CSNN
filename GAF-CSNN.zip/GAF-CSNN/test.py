import numpy as np


array_2 = np.load('test_series/sort_act_bliz_test.npy', allow_pickle=True)
print('1')
array_2 = np.load('test_series/ sort_act_bliz_test.npy', allow_pickle=True)

print('2')

