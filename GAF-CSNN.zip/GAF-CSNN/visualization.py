# 读取每一个文件中的close
import os
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from sklearn import preprocessing

path = r'E:\py_code\FinancialForecastingCNN-main\AAseries'
item = os.listdir(path)
a = []

for i in range(len(item)):
    p = pd.read_csv('E:\py_code\FinancialForecastingCNN-main\AAseries\\'+item[i])
    a.append([len(p),item[i]])
    print(a)
    # 也可以处理成以某一个基准日期进行插补
    plt.title(item[i])
    sclar = preprocessing.MinMaxScaler(feature_range=(0, 1), copy=True)
    p['Close'] = sclar.fit_transform(np.array(p['Close']).reshape(-1,1))
    plt.plot(p['Close'])
plt.show()
path1 = r'E:\py_code\FinancialForecastingCNN-main\vue_Train1'
item1 = os.listdir(path1)
a1 = []

for i in range(len(item1)):
    p1 = pd.read_csv('E:\py_code\FinancialForecastingCNN-main\\vue_Train1\\'+item1[i])
    a1.append([len(p1),item1[i]])
    print(1)
    # sclar = preprocessing.MinMaxScaler(feature_range=(0, 1), copy=True)
    # p1['Close'] = sclar.fit_transform(np.array(p1['Close']).reshape(-1,1))
    # 也可以处理成以某一个基准日期进行插补
    plt.title(item1[i])
    plt.plot(p1['Close'])
plt.show()
# 将多条曲线绘制到同一个维度中类似的数据相关性分析
# 先全部输入进行训练
# 首先找出第一最靠后的时间进行剪裁
# 最后再根据相同的长度最其进行裁剪
# def string_to_date(string: str) -> str:
#     """字符串转日期格式"""
#     from datetime import datetime
#     shift_datetime = datetime.strptime(string, '%Y%m%d')  # 字符串 -> 时间
#     shift_date = shift_datetime.strftime("%Y-%m-%d")  # 时间 -> 任意时间格式
#     return shift_date
# path = r'E:\py_code\FinancialForecastingCNN-main\AAseries\\'
# item = os.listdir(path)
# min_date = string_to_date('20000101')
# for i in range(len(item)):
#     p = pd.read_csv(path+item[i])
#     if min_date<p['Date'][0]:
#         min_date = p['Date'][0]
# print(min_date)
# min_l = 50000
#
# for i in range(len(item)):
#     p = pd.read_csv(path+item[i])
#     p = p.drop(p[p.Date<min_date].index)
#     if min_l>len(p):
#         min_l = len(p)
# for i in range(len(item)):
#     p = pd.read_csv(path+item[i])
#     p = p.drop(p[p.Date<min_date].index)
#     p = p[0:min_l]
#     # dd = item[i].split('.')
#     p.to_csv('AAseries\\'+item[i],index=None)


# 下面将前面的时间全部进行删除
